/********************************************
  Biblioteka procedur obs�ugi magistrali 1W
  Raisonance RC-51
 ********************************************/

#include <reg51.h>

#define MATCH_ROM	0x55		//definicje komend 1W
#define SKIP_ROM	0xCC
#define SEARCH_ROM	0xF0

#define SEARCH_FIRST	0xFF
#define PRESENCE_ERR	0xFF
#define DATA_ERR	0xFF
#define LAST_DEVICE	0x00		//0x00 : znaleziono urz�dzenie
					//0x01...0x40:kontynuacja poszukiwa�

#define	XTAL	110592			//definicja rezonatora (8..25MHz!)
#define	nop()	ACC++			//op�nienie, 1 cykl maszynowy

sbit	one_wire_IO = P1^0;	//definicja pod��czenia linii portu 1W

//wys�anie polecenia "1W Reset"
bit one_wire_reset(void)
{
	unsigned char delay;
	bit err;
	
 			//p�tla op�nienia 480 < t < 960 cykli
	delay = (unsigned char)(XTAL/12e6*480/4);
	do			//p�tle op�niaj�ce s�u�� do wytworzenia
	{			//tzw. time slots, kt�rych dok�adny opis
	   one_wire_IO = 0;	//mo�na znale�� w opisie standardu 1W
	   nop();
	}while(--delay);
 				//p�tla op�nienia 60 < t < 75 cm.
	delay = (unsigned char)( XTAL / 12e6 * 66 / 2 );
	do 
	{
		one_wire_IO = 1;
	}
	while(--delay);
	
	err = one_wire_IO;	//stan niski oznacza, �e urz�dzenie(a) 
 			//1W jest(s�) pod��czone
				//op�nienie 480 < t
	delay = (unsigned char)(XTAL/12e6*(480-66)/4);
	do												{
		nop(); 
		nop();
	} while(--delay);

	err = one_wire_IO
	return !err		//stan niski linii portu 1W oznacza b��d 
}

//przes�anie lub odczyt bitu przez lini� 1W
bit one_wire_bit_io(bit b)
{
	unsigned char delay;

	delay = (unsigned char)(XTAL/12e6*15/2-2);	//15 > t
	one_wire_IO = 0;	//1
	one_wire_IO = b;	//3
	while(--delay);	//3 + delay * 2
	b = one_wire_IO;
	delay = (unsigned char)(XTAL/12e6*45/2);	//60 < t
	while(--delay);
	one_wire_IO = 1;
	return b;
}

//przes�anie bajtu przez lini� 1W
unsigned char one_wire_byte_write(unsigned char b)
{
	unsigned char bit_counter = 8;

	do
	{
	   b = b >> 1 | (one_wire_bit_io( b & 1 ) ? 0x80 : 0);
	}while(--bit_counter);
	return b;
}

//odczyt bajtu z linii 1W
unsigned char one_wire_byte_read( void )
{
  return one_wire_byte_write(0xFF);
}


//wys�anie komendy (komend) do urz�dzenia 1W; lista 8 bajt�w do wys�ania 
//wskazywana przez ptr wype�nienie tablicy wskazywanej przez ptr oznacza, 
//�e komendy dotycz� konkretnego urz�dzenia pod��czonego do 1W; w�wczas
//tablica powinna zawiera� jego identyfikator

void one_wire_send_command(unsigned char command, unsigned char *ptr)
{
	unsigned char byte_count = 8;
	
	one_wire_reset();
	if(ptr)
	{
	   one_wire_byte_write(MATCH_ROM);	//komendy przesy�ane do urz�dzenia
	   do
	   {
		one_wire_byte_write(*ptr);
		ptr++;
	   }while(--byte_count);
	}
	else
	   one_wire_byte_write(SKIP_ROM);	//ptr = null, komenda
						//dla wszystkich urz�dze�
	   one_wire_byte_write(command);
}
