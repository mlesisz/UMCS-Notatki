/* prosty program demonstracyjny "obs�uga 3 cyfr led"
   cyfry LED pod��czona do portu P0, stan aktywny = L,
   za��czanie cyfr przy pomocy kluczy BS250 pod��czonych do P1
   rezonator kwarcowy 8MHz
   seg.A = P0.4
   seg.B = P0.3
   seg.C = P0.6
   seg.D = P0.2
   seg.E = P0.5
   seg.F = P0.1
   seg.G = P0.0
   seg.dp = P0.7
   
   cyfra 1 = P1.2
   cyfra 2 = P1.1
   cyfra 3 = P1.0 */
   
#include <reg51.h>						//do��czenie definicji rejestr�w mikrokontrolera

#define 	PortLED	P0						//port,do kt�rego do�aczone s� segmenty LED
#define	PortSW	P1						//port,do kt�rego do��czone tranzystory kluczy

#define 	_A			0xEF					//definicje segment�w cyfry
#define 	_B			0xF7
#define 	_C			0xBF
#define 	_D			0xFB
#define 	_E			0xDF
#define 	_F			0xFD
#define 	_G			0xFE
#define 	_H			0x7F

#define	LED_1		0xFE					//kody za��czenia poszczeg�lnych cyfr wy�wietlacza
#define	LED_2		0xFD
#define	LED_3		0xFB
#define	LED_off	0xFF

//definicje wygl�du cyfr od 0 do 9
char code Digits[10] = { _A & _B & _C & _D & _E & _F,			//0
								 _B & _C,									//1
								 _A & _B & _D & _E & _G,				//2
								 _A & _B & _C & _D & _G,				//3
								 _B & _C & _F & _G,						//4
								 _A & _C & _D & _F & _G,				//5
								 _A & _C & _D & _E & _F & _G,			//6
								 _A & _B & _C,								//7
								 _A & _B & _C & _D & _E & _F & _G,	//8
								 _A & _B & _C & _D & _F & _G };		//9

 
//op�nienie oko�o 1 sekundy dla kwarcu 8MHz
void Delay(unsigned int time)
{
	unsigned int j;
	
	while (time-- >= 1) for (j=0; j<65; j++);		//p�tla FOR jest powtarzana TIME razy
}


//funkcja zwraca cyfr� b�d�c� na pozycji POSITION
char Subnumber(unsigned int number, char position)
{
	switch (position)
	{
		case 1:
			return(number / 100);				//cyfra 1 - zwr�� cz�� ca�kowit� z dzielenia przez 100
		case 2:
			number %= 100;							//cyfra 2 - dzielenie ca�kowite przez 10 reszty z 
			return(number / 10);					//dzielenia przez 100
		case 3:
			return(number % 10);					//cyfra 3 - reszta z dzielenia przez 10
		default:
			return(0);								//przypadek zabroniony
			break;
	}
}


//pocz�tek programu g��wnego
void main(void)
{
	unsigned int loop, counter;				//zmienne p�tli i licznika
	char i;
	
	while (1)										//p�tla niesko�czona
	{
		for (loop = 0; loop < 30; loop++)
		{
			PortLED = Digits[Subnumber(counter,3)];	//zapis kodu cyfry numer 3 do portu
			PortSW = LED_3;						//za��czenie wy�wietlania cyfry 3
			Delay(20);								//op�nienie oko�o 20ms
			PortSW = LED_off;						//wy��czenie wy�wietlania

			PortLED = Digits[Subnumber(counter,2)];	//zapis kodu cyfry numer 2 do portu
			PortSW = LED_2;						//za��czenie wy�wietlania cyfry 2
			Delay(20);								//op�nienie oko�o 20ms
			PortSW = LED_off;						//wy��czenie wy�wietlania

			PortLED = Digits[Subnumber(counter,1)];	//zapis kodu najstarszej cyfry do portu
			PortSW = LED_1;						//za��cznie cyfry numer 1
			Delay(20);								//op�nienie oko�o 20ms
			PortSW = LED_off;						//wy��czenie wy�wietlania
		}
		counter++;									//zwi�kszenie licznika o 1
	}
}
  
