//===============================================
// (C) Easy Soft 01/2002
// Raisonance RC-51, version 6.4.16
//===============================================
// rezonator 7,3728MHz

//wyb�r modelu pami�ci
#pragma SMALL
//do��czenie definicji rejestr�w mikrokontrolera
#include <reg51.h>
//definicje linii steruj�cych wy�wietaniem
sbit		dataline		= P1^0;
sbit		shiftline 	= P1^1;
sbit		latchline 	= P1^2;
//licznik impuls�w
unsigned int counter = 0;


//warto�� rejestru timera TH1, TL1 nie jest modyfikowane liczy zawsze od 0
const	char interval = 0b11111000;

/* tutaj wzorce cyfr

	   d5
    ======
d1 |	    | d6
	|  d0  |
	 ======
d7 |		 | d4
	|      |
	 ======
	   d2						*/
	   
char code patterns[10] = { 0x09,0xAF,0x1A,0x8A,0xAC,0xC8,0x48,0x8F,0x08,0x88 };
//przecinek = d3, wy��czenie cyfry = 0xFF 
char *TPatterns = &patterns;

//tutaj kolejno�� za��czania
char code digits[6] = { 0xFE,0xFD,0xFB,0xF7,0xEF,0xDF };
char *TDigits = &digits;

//bufor wy�wietlacza w RAM
char data display[7];
char data *TDisplay = &display;


//zamiana zmiennej x na zawarto�� bufora do wy�wietlenia
void Translate(unsigned int x)
{
	char temp;
	
	ET1 = 0;									//wy��czenie na czas translacji wy�wietlania (migotanie LED)
	TDisplay = &display + 5;			//zaczynamy translacj� od najm�odszej cyfry
	for (temp=0; temp<6; temp++)
	{
		*TDisplay = *(TPatterns + x % 10);	//adres wzorca + (reszta z dzielenia przez 10)
		TDisplay--;
		x /= 10;
	}
	TDisplay ++;							//po poprzedniej p�tli TDisplay jest o 1 za ma�e
	for (temp=0; temp<5; temp++)		//wygaszenie zer nieznacz�cych od pozycji 1..5
	{
		if (*TDisplay == *TPatterns) *TDisplay = 0xFF; else break;	//je�li napotkamy znak r�ny od 0,to koniec
		TDisplay++;
	}
	ET1 = 1;									//za��czenie wy�wietlania
}


//procedura obs�ugi przerwania INT0
//zwi�kszanie licznika impuls�w
void IncrementCounter(void) interrupt 0
{
	counter++;								//zwi�kszenie licznika impuls�w
	Translate(counter);					//zamiana counter na liczby do wy�wietlenia
}


//procedura obs�ugi przerwania od timer'a 1
//wys�anie zmiennej 2-bajtowej do wy�wietlacza - 1 znak z bufora display
void DisplaySend(void) interrupt 3
{
	char temp;
	unsigned int x;
	
	TH1 = interval;						//od�wie�enie zawarto�ci timera 1
	TDisplay++;								//nast�pna pozycja do wy�wietlenia
	TDigits++;
	if (*TDisplay == 0)					//je�li osi�gni�to koniec bufora,to wr�� do pocz�tku
	{
		TDisplay = &display;
		TDigits = &digits;
	}
	x = *TDigits;							//x przyjmuje warto�� liczby do wys�ania
	x <<= 8;									//sk�ada si� ona z bajtu wzorca cyfry i bajtu kolejno�ci za��czenia
	x |= *TDisplay;
	
	for (temp = 0; temp<16; temp++)	//wys�anie cyfry poprzez przypisanie flagi C do wyj�cia danych
	{
		x <<= 1;
		dataline = CY;
		shiftline = 1;						//impuls na wyj�ciu zegara przesuwaj�cego
		shiftline = 0;
	}
	latchline = 1;							//przepisanie danych do wyj�� rejestr�w
	latchline = 0;
}

//program g��wny
void main(void)
{
	*(TDisplay + 6) = 0x00;				//tutaj kod ko�ca danych
	Translate(counter);					//wy�wietlenia 0.
	TMOD = 0x11;							//oba timery jako 16 bitowe,kontrolowane wewn�trznie
	TH1 = interval;						//przerwanie wywo�ywane z cz�stotliw.oko�o 75Hz
	ET1 = 1;									//zezwolenie na przerwanie od timer'a 1
	TR1 = 1;									//uruchomienie timer'a 1
	IT0 = 1;									//opadaj�ce zbocze na INT0 wyzwala przerwanie
	EX0 = 1;									//za��czenie przerwania INT0
	EA = 1;									//zezwolenie na przyjmowanie przerwa�
	while (1);								//oczekiwanie na przerwania
}

