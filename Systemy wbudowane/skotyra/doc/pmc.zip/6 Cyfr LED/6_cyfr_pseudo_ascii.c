/*******************************************
 Obs�uga wy�wietlacza 6 cyfr LED z wej�ciem
 szeregowym. Wy�wietlanie kod�w ASCII
 *******************************************/

#pragma SMALL 
//do��czenie definicji rejstr�w mikrokontrolera
#include <reg51.h>
//definicje linii steruj�cych wy�wietlaniem
sbit dataline	= P1^0;
sbit shiftline	= P1^1;
sbit latchline = P1^2;
//warto�� rejestru TH1, TL1 nie jest modyfikowane liczy zawsze od 0
const char interval = 0xF8;

/* tutaj wzorce cyfr i liter

	   d5
    ======
d1 |	    | d6
	|  d0  |
	 ======
d7 |		 | d4
	|      |
	 ======
	   d2						*/
char code patterns[63] = {
//						SP		!		"     #     $     %
						0xFF,	0xB7,	0xBD,	0xEE,	0xC0,	0x3E,
//						&		'		(		)		*		+
						0xEF,	0xBF,	0x59,	0x8B,	0xEF,	0xAE,
//						,		-		.		/		0		1
						0xF7,	0xFF,	0xF7,	0x3E,	0x09,	0xAF,
//						2		3		4		5		6		7
						0x1A,	0x8A,	0xAC,	0xC8,	0x48,	0xF8,
//						8		9		:		;		<		=
						0x08,	0x88,	0xFF,	0xFF,	0xFF,	0xFA,
//						>		?		@		A		b		C
						0xFF,	0x16,	0x19,	0x0C,	0x68,	0x59,
//						d,		E		F		G		H		I
						0x29,	0x58,	0x5C,	0x49,	0x2C,	0xAF,
//						J		K		L		M		n		O
						0xAB,	0x7C,	0x79,	0x6E,	0x6E,	0x09,
//						P		Q		r		S		t		U
						0x1C,	0x01,	0x7E,	0xC8,	0x78,	0x29,
//						V,		W		X		Y		Z		[
						0x29,	0x29,	0x24,	0xAC,	0x1A,	0x59,
//						$		]		^
						0xC8,	0xCB,	0x9A };
char *TPatterns = &patterns;
//tutaj kolejno�� za��czania
char code digits[6] = { 0xFE,0xFD,0xFB,0xF7,0xEF,0xDF };
char *TDigits = &digits;
//bufor wy�wietlacza w RAM
char data display[7];
char data *TDisplay = &display;


//procedura obs�ugi przerwania od timer'a 1
//wys�anie zmiennej 2-bajtowej do wy�wietlacza - 1 znak z bufora display
void DisplaySend(void) interrupt 3
{
	char temp;
	unsigned int x;
	
	TH1 = interval;						//od�wie�enie zawarto�ci timera 1
	TDisplay++;								//nast�pna pozycja do wy�wietlenia
	TDigits++;
	if (*TDisplay == 0)					//je�li osi�gni�to koniec bufora,to wr�� do pocz�tku
	{
		TDisplay = &display;
		TDigits = &digits;
	}
	x = *TDigits;							//x przyjmuje warto�� liczby do wys�ania
	x <<= 8;									//sk�ada si� ona z bajtu wzorca cyfry i bajtu kolejno�ci za��czenia
	
	TPatterns = patterns + (*TDisplay-0x20);
	x |= *TPatterns;						//kod znaku wskazywanego przez TDisplay i kod spacji
	
	for (temp = 0; temp<16; temp++)	//wys�anie cyfry poprzez przypisanie flagi C do wyj�cia danych
	{
		x <<= 1;
		dataline = CY;
		shiftline = 1;						//impuls na wyj�ciu zegara przesuwaj�cego
		shiftline = 0;
	}
	latchline = 1;							//przepisanie danych do wyj�� rejestr�w
	latchline = 0;
}

//program g��wny
void main(void)
{
	display[0] = 'H';						//umieszczenie napisu w buforze
	display[1] = 'E';
	display[2] = 'L';
	display[3] = 'L';
	display[4] = 'O';
	display[5] = '!';
	display[6] = 0;
	
	TMOD = 0x11;							//oba timery jako 16 bitowe,kontrolowane wewn�trznie
	TH1 = interval;						//przerwanie wywo�ywane z cz�stotliw.oko�o 75Hz
	ET1 = 1;									//zezwolenie na przerwanie od timer'a 1
	TR1 = 1;									//uruchomienie timer'a 1
	EA = 1;									//zezwolenie na przyjmowanie przerwa�
	while (1);								//oczekiwanie na przerwania
}

