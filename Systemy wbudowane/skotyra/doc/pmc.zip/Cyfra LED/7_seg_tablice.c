/* prosty program demonstracyjny "obs�uga cyfry led"
   cyfra LED pod��czona do portu P0, stan aktywny = L,
   rezonator kwarcowy 8MHz
   seg.A = P0.4
   seg.B = P0.3
   seg.C = P0.6
   seg.D = P0.2
   seg.E = P0.5
   seg.F = P0.1
   seg.G = P0.0
   seg.dp = P0.7 */
   
#include <reg51.h>						//do��czenie definicji rejestr�w mikrokontrolera

#define 	PortLED	P0
#define 	_A			0xEF					//definicje segment�w cyfry
#define 	_B			0xF7
#define 	_C			0xBF
#define 	_D			0xFB
#define 	_E			0xDF
#define 	_F			0xFD
#define 	_G			0xFE
#define 	_H			0x7F

//definicje wygl�du cyfr od 0 do 9
char code Digits[10] = { _A & _B & _C & _D & _E & _F,			//0
								 _B & _C,									//1
								 _A & _B & _D & _E & _G,				//2
								 _A & _B & _C & _D & _G,				//3
								 _B & _C & _F & _G,						//4
								 _A & _C & _D & _F & _G,				//5
								 _A & _C & _D & _E & _F & _G,			//6
								 _A & _B & _C,								//7
								 _A & _B & _C & _D & _E & _F & _G,	//8
								 _A & _B & _C & _D & _F & _G };		//9
								 

//op�nienie oko�o 0,2 sekundy dla kwarcu 8MHz
void Delay(unsigned int time)
{
	unsigned int j;
	
	while (time >= 1)						//wykonanie p�tli FOR zajmuje oko�o 1 sek.
	{											//p�tla jest powtarzana TIME razy
		for (j=0; j<65500; j++);
		time--;
	}
}

//pocz�tek programu g��wnego
void main(void)
{
	char counter;							//zmienna licznika
	
	while (1)								//p�tla niesko�czona
	{
		PortLED = Digits[counter];		//wpisanie warto�ci wy�wietlacza LED do portu
		Delay(15);							//op�nienie 3 sekundy
		counter++;							//zwi�kszenie licznika o 1
		if (counter > 9) counter = 0;			//gdy licznik przekracza 9, zeruj go
	}
}
 
