#pragma DEFJ(TIM1_INIT=0xFE)									//timer 1 jako pr�dko�� transmisji (19200bps)
																		//dla rezonatora 11,0592MHz TH1=0xFD; dla 7,3728MHz TH1 = 0xFE
#pragma SMALL														//wyb�r modelu pami�ci programu
#include "reg8252.h"												//definicje rejestr�w
#include "stdio.h"												//funkcje wej�cia - wyj�cia

#define WORD unsigned int

//bit umo�liwiaj�cy "wy��czenie" realizowania polece� przez terminal
bit ON = 1;

//definicje nag��wk�w funkcji programu
char in(char data *bufor);
char out(char data *bufor);
char status(char data *bufor);
char on(char data *bufor);
char off(char data *bufor);
char help(char data *bufor);


//definicja typu dla tablicy - wykazu polece�
typedef struct
{
  char code *komenda;
  char (code *funkcja)(char data *);
}komendy;


//tablica z wykazem polece�
code komendy wykaz[] = 											//wykaz komend i powi�zanych z nimi funkcji
{
	"IN", in,
	"OUT", out,
	"STATUS", status,
	"ON", on,
	"OFF", off,
	"HELP", help,
	"?", help,
	"", NULL       												//koniec wykazu
};


//odczyt portu o podanym numerze
char in(char data *bufor)
{
	int port;
	char odczyt;

	if (ON)
	{
		if(sscanf(bufor, "%i", &port ) != 1 ) 				//funkcja SCANF zwraca warto�� integer zawieraj�c� numer portu
  			printf("%s\n", "Podaj numer portu!");			//je�li brak numeru, to komunikat o b��dzie
  		else
  		{
	  		switch(port)
			{
	   		case 0:												//port 0
		    		odczyt = P0; 
			    	break;
	   		case 1:												//port 1
	    			odczyt = P1; 
	    			break;
		   	case 2:												//port 2
		    		odczyt = P2; 
	   	 		break;
	   		case 3:												//port 3
		    		odczyt = P3; 
		    		break;
	   		default:												//poza zakresem
	    			printf("%s\n", "Bledny numer portu!");
	    			return(0);
			}
			printf( "Port P%d = %02X (%d)\n", port, odczyt, odczyt );
		}
	}
	else
	{
		printf("%s\n","BLAD: Urzadzenie wylaczone");		//komunikat o wy��czeniu
	}
	return 0;
}


char out(char data *bufor)
{
  WORD port, wartosc;
  
	if (ON)
	{
		if(sscanf(bufor, "%i%i", &port, &wartosc ) != 2 ) 
			printf("%s\n", "Bledne argumenty wywolania! Podaj: OUT <port> <wartosc>");
		else
		{
			switch(port)
  			{
				case 0: 												//port 0
					P0 = wartosc; 
					break;
				case 1: 												//port 1
					P1 = wartosc; 
					break;
				case 2: 												//port 2
					P2 = wartosc; 
					break;
				case 3: 												//port 3
					P3 = wartosc | RXD | TXD;
					break;
				default:
					printf("%s\n", "Bledny numer portu!");
			}
		}
	}
	else
	{
		printf("%s\n","BLAD: Urzadzenie wylaczone");		//komunikat o wy��czeniu
	}
	return(0);
}


//podanie statusu "sterownika"
char status(char data *bufor)
{
	if (ON) printf("%s\n","STATUS = AKTYWNY"); else printf("%s\n","STATUS = WYLACZONY");
	return(0);
}


//za��czenie sterownika
char on(char data *bufor)
{
	ON = 1;
}


//wy��czenie sterownika
char off(char data *bufor)
{
	ON = 0;
}


//opisy komend
char help(char data *bufor)
{
  char code *opis = 	
  			"Realizowane polecenia:\n"
			"in <numer portu> (odczyt portu o podanym numerze)\n"
			"out <numer portu> <wartosc> (zapis do portu o podanym numerze liczby WARTOSC)\n"
			"status (informacja o statusie WYL./AKT. \n"
			"on (zalaczenie przyjmowania nastaw) \n"
			"off (wylaczenie przyjmowania nastaw) \n"
			"help lub ? (informacja o realizowanych poleceniach)\n";
  printf( "%s", opis );
  return(0);
}


//wyszukiwanie komend oraz wywo�anie odpowiadajacych im funkcji
char command(char data *bufor)
{
	char i, j;														//indeksy dla 256 komend o maks.d�ugo�ci 256 znak�w
	
	for (i = 0;;)
		for (j = 0;; )
		{
			if(wykaz[i].komenda[j] != 0)						//je�li komenda w wykazie r�na od znaku "pustego"
			{
				if(((wykaz[i].komenda[j]^bufor[j]) & 0x5F) == 0)	//odrzucamy kody ASCII ma�ych liter(zamiana na du�e)
				{
          		j++;
		 			continue;										//nast�pny znak
				}
				i++;
				break;                  						//nast�pna komenda
		}
		if( j == 0 ) 
		{
			printf("%s\n","BLAD: Nie rozpoznano komendy!");	//b��d - nie ma komendy w wykazie
			return(0);
		} else return (wykaz[i].funkcja(bufor+j));		//powr�t pod adres - wska�nik, to jest wykonanie funkcji spod
	}																	//wskazanego adresu
}



//program g��wny
void main()
{
	char data bufor[21];

	PCON |= 0x80;													//ustawienie bitu prescalera zegara transmisji
	while(1)
	{
		putchar('>');												//gotowo�� do przyj�cia komendy
		gets(bufor);												//pobranie komendy
		command(&bufor);											//wykonanie komendy
		printf("%s\n","OK");
	}
}

