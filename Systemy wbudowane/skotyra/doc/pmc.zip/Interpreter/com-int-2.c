#pragma DEFJ(TIM1_INIT=0xFE)								//timer 1 jako pr�dko�� transmisji (19200bps)
																	//dla rezonatora 11,0592MHz TH1=0xFD; dla 7,3728MHz TH1 = 0xFE
#pragma SMALL													//wyb�r modelu pami�ci programu
#include "reg8252.h"											//definicje rejestr�w
#include "stdio.h"											//funkcje wej�cia - wyj�cia
#include "lcd4b.h"

#define WORD unsigned int

//bit umo�liwiaj�cy "blokad�" funkcji programu
bit ON = 1;

//definicje nag��wk�w funkcji realizujacych polecenia
char cursor(char data *bufor);
char clr(char data *bufor);
char gotoxy(char data *bufor);
char write(char data *bufor);
char cwrite(char data *bufor);
char fill(char data *bufor);
char define(char data *bufor);
char help(char data *bufor);
char on(char data *bufor);
char off(char data *bufor);
char status(char data *bufor);
char init(char data *bufor);


//definicja typu dla tablicy polece�
typedef struct
{
  char code *komenda;										//wska�nik do nazwy komendy w obszarze CODE
  char (code *funkcja)(char data *);					//typ dokonuj�cy konwersji nazwy funkcji na wska�nik do tej funkcji
}komendy;


code komendy wykaz[] = 										//wykaz komend i powi�zanych z nimi funkcji
{
	"CURSOR", cursor,
	"CLR", clr,
	"GOTOXY", gotoxy,
	"WRITE", write,
	"CWRITE", cwrite,
	"FILL", fill,
	"DEF", define,
	"INIT", init,
	"ON", on,
	"OFF", off,
	"STATUS", status,
	"HELP", help,
	"?", help,
	"", NULL       											//koniec wykazu
};


//funkcja pomocnicza - wys�anie przez UART komunikatu o wy��czeniu funkcji programu
void blokada()                         				
{
	printf("%s\n","BLAD: Blokada dostepu");
}


//funkcja obs�ugi za��czenia - wy��czenia kursora
char cursor(char data *bufor)
{
	WORD temp;
	
	if (ON)
	{
		if(sscanf(bufor, "%i", &temp ) != 1) printf("%s\n", "Blad! Podaj CURSOR <kod 0..2>");	//komunikat o b��dzie
  		else switch (temp)
  		{
  			case 0:
  				WriteToLcdCtrlRegister(0x0C);
  				break;
  			case 1:
  				WriteToLcdCtrlRegister(0x0E);
  				break;
  			case 2:
  				WriteToLcdCtrlRegister(0x0F);
  				break;
  			default:
  				printf("%s\n","Parametr musi by� z zakresu 0..2");
  		}
	}
	else
	{
		blokada();												//komunikat o wy��czeniu
	}
	return 0;
}


//kasowanie ekranu LCD
char clr(char data *bufor)
{
	if (ON) LcdClrScr(); else blokada();
}


//pozycjonowanie kursora na ekranie LCD na wsp�rz�dnych X, Y
char gotoxy(char data *bufor)
{
  WORD x, y;
  
	if (ON)
	{
		if(sscanf(bufor, "%i%i", &x, &y) != 2 ) printf("%s\n", "Blad! Podaj: GOTOXY <x> <y>");
		else LcdGotoXY(x, y);
	}
	else
	{
		blokada();												//komunikat o wy��czeniu
	}
	return(0);
}


//wy�wietlenie tekstu podanego jako parametr wywo�ania
char write(char data *bufor)
{
	if (ON)
	{
		bufor++;
		while (*bufor != 0x0D && *bufor != 0) LcdWrite(*bufor++);
	}
	else
	{
		blokada();												//komunikat o wy��czeniu
	}
	return(0);
}
	
	
//wy�wietlenie znaku o kodzie podanym jako parametr wywo�ania
char cwrite(char data *bufor)
{
	WORD x;

	if (ON)
	{
		if(sscanf(bufor, "%i", &x) != 1) printf("%s\n", "Blad! Podaj: CWRITE <kod>");
		else LcdWrite(x);
	}
	else
	{
		blokada();												//komunikat o wy��czeniu
	}
	return(0);
}
	
	
//wype�nienie ekranu LCD znakami o kodzie podanym jako parametr wywo�ania
char fill(char data *bufor)
{
	WORD x;
	char i;
	
	if (ON)
	{
		if(sscanf(bufor, "%i", &x) != 1) printf("%s\n", "Blad! Podaj: FILL <kod>");
		else 
		{
			LcdClrScr();
			for (i=0; i<81; i++) LcdWrite(x);
		}
	}
	else
	{
		blokada();												//komunikat o wy��czeniu
	}
	return(0);
}


//definiowanie w�asnych znak�w
char define(char data *bufor)
{
	WORD x, by0, by1, by2, by3, by4, by5, by6, by7;
	
	if (ON)
	{
		if(sscanf(bufor, "%i%i%i%i%i%i%i%i%i", &x, &by0, &by1, &by2, &by3, &by4, &by5, &by6, &by7) != 9) 
			printf("%s\n", "Blad! Podaj: DEF <kod> <bajt0> <bajt1> <bajt2> <bajt3> <bajt4> <bajt5> <bajt6> <bajt7> ");
		else 
		{
			if (x < 10)
			{
				WriteToLcdCtrlRegister(0x40);				//ustawienie trybu definicji
				LcdWrite(by0);
				LcdWrite(by1);
				LcdWrite(by2);
				LcdWrite(by3);
				LcdWrite(by4);
				LcdWrite(by5);
				LcdWrite(by6);
				LcdWrite(by7);
				WriteToLcdCtrlRegister(0x80);				//prze��czenie do trybu wy�wietlania
			}
			else
			{
				printf("%s\n", "Bledny kod znaku (0..9) lub polecenie!");
			}
		}
	}
	else
	{
		blokada();												//komunikat o wy��czeniu
	}
	return(0);
}


//funkcja inicjalizacji wy�wietlacza
char init(char data *bufor)
{
	if (ON)
	{
		LcdInitialize();
		LcdClrScr();
	} else blokada();
}


//podanie statusu "sterownika"
char status(char data *bufor)
{
	if (ON) printf("%s\n","STATUS = AKTYWNY"); else printf("%s\n","STATUS = WYLACZONY");
	return(0);
}


//za��czenie sterownika
char on(char data *bufor)
{
	ON = 1;
}


//wy��czenie sterownika
char off(char data *bufor)
{
	ON = 0;
}


//opisy komend
char help(char data *bufor)
{
  char code *opis = 	
  			"Realizowane polecenia:\n"
			"CURSOR <kod> (zmiana kursora,kod=0..2)\n"
			"CLR (kasowanie ekranu)\n"
			"GOTOXY <x> <y> (ustawienie kursora na x, y)\n"
			"WRITE <tekst> (wyswietlenie tekstu)\n"
			"CWRITE <kod> (wyswietlenie znaku o kodzie <kod>)\n"
			"FILL <kod> (wypelnienie LCD znakiem)\n"
			"DEF <kod> <bajt0> .. <bajt7> (definiowanie znaku)\n"
			"INIT (inicjalizacja wyswietlacza)\n"
			"STATUS (informacja o statusie WYL./AKT. \n"
			"ON (zalaczenie przyjmowania polecen) \n"
			"OFF (wylaczenie przyjmowania polecen) \n"
			"HELP lub ? (informacja o realizowanych poleceniach)\n";
  printf( "%s", opis );
  return(0);
}


//wyszukiwanie komend oraz podejmowanie akcji zale�nie od wska�nika w tablicy
char command(char data *bufor)
{
	char i, j;														//indeksy dla 256 komend o maks.d�ugo�ci 256 znak�w
	
	for (i = 0;;)
		for (j = 0;; )
		{
			if(wykaz[i].komenda[j] != 0)						//je�li komenda w wykazie r�na od znaku "pustego"
			{
				if(((wykaz[i].komenda[j]^bufor[j]) & 0x5F) == 0)	//odrzucamy kody ASCII ma�ych liter(zamiana na du�e)
				{
          		j++;
		 			continue;										//nast�pny znak
				}
				i++;
				break;                  						//nast�pna komensa
		}
		if( j == 0 ) 
		{
			printf("%s\n","BLAD: Nie rozpoznano komendy!");	//b��d - nie ma komendy w wykazie
			return(0);
		}
		else return (wykaz[i].funkcja(bufor+j));			//powr�t pod adres - wska�nik, to jest wykonanie funkcji spod
	}																	//wskazanego adresu
}



//program g��wny
void main()
{
	char data bufor[41];

	LcdInitialize();												//inicjalizacja wy�wietlacza
	LcdClrScr();
	
	PCON |= 0x80;													//ustawienie bitu prescalera zegara transmisji
	while(1)
	{
		putchar('>');												//gotowo�� do przyj�cia komendy
		gets(bufor);												//pobranie komendy
		command(&bufor);											//wykonanie komendy
		printf("%s\n","OK");
	}
}

