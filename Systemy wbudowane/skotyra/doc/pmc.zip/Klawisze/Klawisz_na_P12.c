/* prosty program demonstracyjny "odczyt pojedynczego klawisza"
   klawisz w��czony pomi�dzy mas� a port P1.2, stan aktywny = L;
   rezonator kwarcowy 8MHz */
   
#include <reg51.h>				//do��czenie definicji rejestr�w mikrokontrolera

sbit PortKey = P1^2;				//definicja bitu portu do kt�rego pod��czony klawisz
sbit Active = P1^3;				//port przyjmuje stan niski, gdy klawisz jest wci�ni�ty


//op�nienie oko�o 1 milisekundy dla kwarcu 8MHz
void Delay(unsigned int time)
{
	unsigned int j;
	
	while (time >= 1)				//wykonanie p�tli FOR zajmuje oko�o 1 sek.
	{									//p�tla jest powtarzana TIME razy
		for (j=0; j<65; j++);
		time--;
	}
}

//funkcja - reakcja na naci�ni�cie klawisza
void KeyPressed(void)
{
	Active = 0;
}

//funkcja - reakcja, gdy klawisz nie jest wci�ni�ty
void KeyNotPressed(void)
{
	Active = 1;
}

//pocz�tek programu g��wnego
void main(void)
{
	while (1)						//p�tla niesko�czona
	{
		if (!PortKey)
		{
			Delay(20);				//op�nienie 20 ms
			if (!PortKey) 			//ponowny odczyt klawisz i podj�cie akcji, je�li nadal wci�ni�ty
			{
				KeyPressed;
				while (!PortKey);	//oczekiwanie na zwolnienie klawisza
			}
		}
		KeyNotPressed();			//podj�cie akcji, gdy klawisz nie jest wci�ni�ty
	}
}
 
