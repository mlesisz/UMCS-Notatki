/* prosty program demonstracyjny "odczyt klawiszy pod��czonych do P1"
   klawisz w��czony pomi�dzy mas� a bit portu P1, stan aktywny = L
   klawisze pod��czone od P1.2 do P1.6; rezonator kwarcowy 8MHz */
   
#include <reg51.h>			//do��czenie definicji rejestr�w mikrokontrolera
#include <stdio.h>			//biblioteka zawieraj�ca funkcj� printf()

#define PortKey	P1;		//definicja bitu portu klawisza
unsigned char	 buf;			//zmienna przechowuj�ca stan klawiszy

//op�nienie oko�o 1 milisekundy dla kwarcu 8MHz
void Delay(unsigned int time)
{
	unsigned int j;
	
	while (time >= 1)			//wykonanie p�tli FOR zajmuje oko�o 1 msek.
	{								//p�tla jest powtarzana TIME razy
		for (j=0; j<65; j++);
		time--;
	}
}

//odczyt klawiatury pod��czonej do PortKey
char KbdRead()
{
	unsigned char b;

	b = PortKey;				//odczytaj stan portu klawiatury
	b |= 3;						//ustaw dwa najm�odsze, nie u�ywane przez klawiatur� bity
	return (~b);				//zwr�� odczytan� warto�� po zanegowaniu
}


//pocz�tek programu g��wnego
void main(void)
{
	while (1)					//p�tla niesko�czona
	{
		buf = KbdRead();
		if (buf)					//je�li rezultat r�ny od 0 - sprawd�
		{
			Delay(20);			//op�nienie 20ms
			if (buf == KbdRead())	//ponowny odczyt klawisza i akcja,
	 		{								//je�li nadal wci�ni�ty
 				if (buf && 0x04) printf("%s\n", "Klawisz 1");
				if (buf && 0x08) printf("%s\n", "Klawisz 2");
				if (buf && 0x10) printf("%s\n", "Klawisz 3");
				if (buf && 0x20) printf("%s\n", "Klawisz 4");
				if (buf && 0x40) printf("%s\n", "Klawisz 5");
			}
		}
	}
}

