/* prosty program demonstracyjny "odczyt klawiatury matrycowej"
   wiersze P1.2 do P1.4, kolumny P1.5 do P1.6 (3x3 = 9 klawiszy)
   rezonator kwarcowy 8MHz */
   
#include <reg51.h>					//do��czenie definicji rejestr�w mikrokontrolera
#include <stdio.h>					//do��czenie prototypu funkcji printf

#define PortKey	P1					//definicja bitu portu klawisza

#define Column_1	0b11111011		//definicje stan�w bit�w kolumn
#define Column_2	0b11110111
#define Column_3	0b11101111
#define Dummy		0b00011100		//warto�� dla ustawienia bit�w kolumn na "1"

#define Row_1		0b00100000		//definicje po��cze� bit�w wierszy
#define Row_2		0b01000000
#define Row_3		0b10000000

//op�nienie oko�o 1 milisekundy dla kwarcu 8MHz
void Delay(unsigned int time)
{
	unsigned int j;
	
	while (time >= 1)					//wykonanie p�tli FOR zajmuje oko�o 1 msek.
	{										//p�tla jest powtarzana TIME razy
		for (j=0; j<65; j++);
		time--;
	}
}

//odczyt portu klawiatury
unsigned char PortKeyRead(unsigned char column)
{
	unsigned char curr, prev;
	
	PortKey |= Dummy;					//ustawienie na warto�� "1" bit�w kolumn
	PortKey &= column;				//stan niski kolumny 1
	prev = PortKey;					//odczyt portu klawiatury
	prev &= 0xE0;						//maskowanie wszystkich bit�w opr�cz wierszy
	if (prev == 0xE0) return (0);	//je�li wszystkie bity s� jedynkami dla danej kolumny
											//nie wci�ni�to �adnego klawisza
											
	Delay(20);							//eliminacja drga� styk�w poprzez powt�rny odczyt i por�wnanie
	curr = PortKey;
	curr &= 0b11100000;
	if (curr == prev) 
	{
		while (prev = curr)			//czekaj na zwolnienia klawisza
		{
			prev = PortKey;
			prev &= 0xE0;
		}
		return(~curr);					//zamiana aktywnych bit�w z 0 na 1
	}
	else return(0);					//zwr�� 0 w przypadku r�nic odczyt�w
}


//odczyt klawiatury pod��czonej do PortKey
//funkcja zwraca numer wci�ni�tego klawisza
unsigned char KeyNumber()
{
	unsigned char b;
	
	b = PortKeyRead(Column_1);		//odczyt: kolumna 1 - wiersz 1, 2, 3
	if (!b)
	{
		if (b && Row_1) return(3);
		if (b && Row_2) return(6);
		if (b && Row_3) return(9);
	}

	b = PortKeyRead(Column_2);		//odczyt: kolumna 2 - wiersz 1, 2, 3
	if (!b)
	{
		if (b && Row_1) return(2);
		if (b && Row_2) return(5);
		if (b && Row_3) return(8);
	}

	b = PortKeyRead(Column_3);		//odczyt: kolumna 3 - wiersz 1, 2, 3
	if (!b)
	{
		if (b && Row_1) return(1);
		if (b && Row_2) return(4);
		if (b && Row_3) return(7);
	}
	
	return(0);							//nie wci�ni�to �adnego klawisza, zwr�� 0
}


//pocz�tek programu g��wnego
void main(void)
{
	while (1)							//p�tla niesko�czona
	{
		char buf = KeyNumber();		//odczyt numeru klawisza po��czony z deklaracj� buf
		if (!buf) printf("%s\n",buf);	//wys�anie numeru klawisza przez RS232
	}
}

