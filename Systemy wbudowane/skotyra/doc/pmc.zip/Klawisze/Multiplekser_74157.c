/* prosty program demonstracyjny "odczyt klawiszy pod��czonych przez 74157"
   wykorzystane s� bity P1.0 do P1.3 oraz P3.7 do sterowania wyborem
   po��wki odczytywanego bajtu; rezonator kwarcowy 8MHz */
   
#include <reg51.h>					//do��czenie definicji rejestr�w mikrokontrolera
#include <stdio.h>					//biblioteka zawieraj�ca funkcj� printf()

#define PortKey	P1;				//definicja bitu portu klawisza
sbit A_B = P3^7;						//wyb�r po��wki bajtu odczytywanej przez 74157

//op�nienie oko�o 1 milisekundy dla kwarcu 8MHz
void Delay(unsigned int time)
{
	unsigned int j;
	
	while (time >= 1)					//wykonanie p�tli FOR zajmuje oko�o 1 msek.
	{										//p�tla jest powtarzana TIME razy
		for (j=0; j<65; j++);
		time--;
	}
}

//odczyt klawiatury pod��czonej do PortKey
char KbdRead()
{
	unsigned char L_nibble, H_nibble;

	A_B = 1;								//odczyt starszej po��wki bajtu (klawisze parzyste)
	H_nibble = PortKey;
	H_nibble &= 0x0F;
	H_nibble <<= 4;
	A_B = 0;								//teraz odczyt m�odszej po��wki bajtu (klawisze nieparzyste)
	L_nibble = PortKey;
	L_nibble &= 0x0F;
	
	return (~(H_nibble | L_nibble));		//zwr�� odczytan� warto�� po zanegowaniu
}


//pocz�tek programu g��wnego
void main(void)
{
	while (1)							//p�tla niesko�czona
	{
		buf = KbdRead();
		if (buf)							//je�li rezultat r�ny od 0 - sprawd�
		{
			Delay(20);					//op�nienie 20ms
			if (buf == KbdRead()) 	//ponowny odczyt klawisza i podj�cie akcji, je�li nadal wci�ni�ty
	 		{
 				if (buf && 0x01) printf("%s\n", "Klawisz 1");
				if (buf && 0x02) printf("%s\n", "Klawisz 2");
				if (buf && 0x04) printf("%s\n", "Klawisz 3");
				if (buf && 0x08) printf("%s\n", "Klawisz 4");
				if (buf && 0x10) printf("%s\n", "Klawisz 5");
 				if (buf && 0x20) printf("%s\n", "Klawisz 6");
				if (buf && 0x40) printf("%s\n", "Klawisz 7");
				if (buf && 0x80) printf("%s\n", "Klawisz 8");
			}
		}
	}
}

