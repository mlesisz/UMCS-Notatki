/* prosty program demonstracyjny "przerwanie generowane po wci�ni�ciu klawisza"
   wykorzystane s� bity P1.0 do P1.4 oraz wej�cie zewn�trznego przerwania INT0
   rezonator kwarcowy 8MHz */
   
#include <reg51.h>					//do��czenie definicji rejestr�w mikrokontrolera
#include <stdio.h>					//prototyp funkcji printf

#define PortKey	P1					//definicja bitu portu klawisza
#define Key_1		0b00000001		//maski dla poszczeg�lnych bit�w klawiszy
#define Key_2		0b00000010
#define Key_3		0b00000100
#define Key_4		0b00001000
#define Key_5		0b00010000
#define mask		0b00011111		//maska bit�w klawiatury dla operacji logicznych

unsigned char status = 0;			//status klawiatury, ustawianiy w obs�udze przerwania


//odczyt klawiatury pod��czonej do PortKey
//jest to funkcja obs�ugi przerwania u�ywaj�ca banku rejestr�w 1
void KbdRead() interrupt 1 using 1
{
	int i;
	unsigned char p;

	p = PortKey;						//odczyt bit�w portu
	p = ~p & mask;
	for (i=0; i<1300; i++);			//pauza 20 ms dla rezonatora 8MHz
	status = PortKey;					//ponowny odczyt bit�w klawiatury dla weryfikacji
	status = ~status & mask;
	if (p != status) status = 0;	//ustawienie zmiennej status
}


//pocz�tek programu g��wnego
void main(void)
{
	PortKey |= ~mask;					//ustawienie linii klawiatury
	EX0 = 1;								//zezwolenie na przyjmowanie przerwa� INT0
	EA = 1;								//za��czenie przerwa�
	while (1)							//p�tla niesko�czona
	{
		if (status)
		{
			if (status && Key_1) printf("%s\n","Klawisz 1");
			if (status && Key_2) printf("%s\n","Klawisz 2");
			if (status && Key_3) printf("%s\n","Klawisz 3");
			if (status && Key_4) printf("%s\n","Klawisz 4");
			if (status && Key_5) printf("%s\n","Klawisz 5");
			status = 0;
		}
	}
}

