#include <reg51.h>
// port,do kt�rego pod��czono wy�wietlacz LCD
#define	PORT			P2
// bity steruj�ce LCD
#define	ENABLE 		PORT^0
#define	READ	 		PORT^3
#define	REGISTER		PORT^1
// op�nienie oko�o 1 milisekundy dla kwarcu 7,3728MHz
void Delay (unsigned int k);
// zapis bajtu do lcd
void WriteByteToLcd(char X);
// zapis bajtu do rejestru kontrolnego LCD
void WriteToLcdCtrlRegister(char X);
// zapis bajtu do pami�ci obrazu
void LcdWrite(char X);
// czyszczenie ekranu LCD
void LcdClrScr(void);
// inicjalizacja wy�wietlacza LCD w trybie 4 bity
void LcdInitialize(void);
// ustawia kursor na wsp�rz�dnych x,y
void GotoXY(char x, char y);
// wy�wietla tekst na wsp�rz�dnych x, y
void WriteTextXY(char x, char y, char *S);
// wy�wietla tekst na wsp�rz�dnych x, y
void WriteText(char *S);
// definiowanie znak�w z tablicy CGRom
void DefineSpecialCharacters(char *ptr);

