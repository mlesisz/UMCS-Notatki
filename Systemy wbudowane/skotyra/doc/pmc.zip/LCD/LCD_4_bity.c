/************************************************
 Obs�uga wy�wietlacza LCD w trybie 4 bity
 RC-51 Raisonance
*************************************************/
// wyb�r modelu pami�ci	
#pragma SMALL
// do��czenie definicji rejestr�w '51
#include <reg51.h>

// definicje znak�w specjalnych dla wy�wietlacza LCD
char code CGRom[65] = {	0xAA,0x55,0xAA,0x55,0xAA,0x55,0xAA,0x55,		// "kratka"			0x00
								0xC0,0xC0,0xFF,0xF1,0xF1,0xF1,0xFF,0xC0,		// pusty kwadrat	0x01
							  	0xC0,0xC0,0xFF,0xFF,0xFF,0xFF,0xFF,0xC0,		// kwadrat zacz.	0x02
							  	0xE0,0xFF,0xFF,0xFF,0xE0,0xE0,0xE0,0xE0,		// linia				0x03
							  	0xFF,0xFF,0xF9,0xF3,0xE7,0xF3,0xF9,0xFF,		// znak w lewo		0x04
							  	0xFF,0xFF,0xF3,0xF9,0xFC,0xF9,0xF3,0xFF,		// znak w prawo	0x05
				           	0xFF,0xFF,0xFB,0xF1,0xE4,0xEE,0xFF,0xFF,		// znak w g�r�		0x06
				           	0xFF,0xFF,0xFF,0xEE,0xE4,0xF1,0xFB,0xFF,		// znak w d�		0x07
				           	0x00};

// port,do kt�rego pod��czono wy�wietlacz LCD
#define	PORT			P2
// 4 najstarsze bity, to bity danych, 4 m�odsze mog� by� w dowolny spos�b skonfigurowane jako steruj�ce
// po zmianie definicji mog� to by� r�wnie� 2 r�ne porty,jednak w programie przyk�adowym zak�adam 
// wykorzystanie tylko jednego z port�w mikrokontrolera

// bity steruj�ce LCD
sbit LcdEnable = 		PORT^0;
sbit LcdRead = 		PORT^3;
sbit LcdReg = 			PORT^1;


// op�nienie oko�o 1 milisekundy dla kwarcu 7,3728MHz
void Delay (unsigned int k) 	
{
	unsigned int i,j;
	for (j = 0; j < k; j++)
		for (i = 0; i <= 296; i++);
}


// zapis bajtu do lcd,osobna procedura dla zmniejszenia obj�to�ci kodu wynikowego
void WriteByteToLcd(char X)
{
	LcdEnable = 1;
	PORT |= 0xF0;							// ustawienie g�rnej po��wki portu PORT na "1"
	PORT &= (X | 0x0F);					// "bezkolizyjny" zapis 1-szej po��wki bajtu (przez funkcj� logiczn�)
	LcdEnable = 0;							// zapis do wy�wietlacza (opadaj�ce zbocze sygna�u E)
	LcdEnable = 1;							// zapis 2-giej po��wki bajtu
	X <<= 4;									// przesuni�cie 4x w lewo
	PORT |= 0x0F;							// maskowanie 4 m�odszych bit�w
	PORT |= (X | 0xF0);					// ustawienie g�rnej po��wki portu PORT na "1"
												// maskowanie 4 m�odszych bit�w
	LcdEnable = 0;							// opadaj�ce zbocze E - zapis do LCD
	Delay(1);								// czas na przetwarzanie dla LCD
}

// zapis bajtu do rejestru kontrolnego LCD
void WriteToLcdCtrlRegister(char X)
{
	LcdReg = LcdRead = 0;				// ustawienie sygna��w steruj�cych
	WriteByteToLcd(X);
}


// zapis bajtu do pami�ci obrazu
void LcdWrite(char X)
{
	LcdReg = 1;								// ustawienie sygna��w steruj�cych
	LcdRead = 0;
	LcdEnable = 1;
	WriteByteToLcd(X);
}


// czyszczenie ekranu LCD
void LcdClrScr(void)
{
	WriteToLcdCtrlRegister(0x01);
}


// inicjalizacja wy�wietlacza LCD w trybie 4 bity
void LcdInitialize(void)
{
	char i;
	
	Delay(15);
	P0 = 0x0F;								// wyzerowanie linii LcdReg,LcdRead,LcdEnable
	for (i = 0; i<3; i++)
	{
		LcdEnable = 1;						// impuls na E
		PORT &= 0x3F;						// ustawienie wart.inicjuj�cej
		LcdEnable = 0;
		Delay(5);
	}
	LcdEnable = 1;							// wpisanie warto�ci 2 do rej.kontr.
	PORT &= 0x2F;							// tylko "g�rne" 4 bity
	LcdEnable = 0;
	Delay(1);
	WriteToLcdCtrlRegister(0x28);		// interfejs 4 bity,znaki 5x7
	WriteToLcdCtrlRegister(0x08);		// wy��czenie LCD
	WriteToLcdCtrlRegister(0x01);		// kasowanie ekranu,powr�t do home
	WriteToLcdCtrlRegister(0x06);		// przesuwanie kursora z inkrement.
	WriteToLcdCtrlRegister(0x0C);		// za��czenie wy�wietlacza
}

	
// ustawia kursor na wsp�rz�dnych x,y
void GotoXY(char x, char y)
{
	switch (y)								// obliczenie o ile nale�y zwi�kszy� x w zale�no�ci od warto�ci y 
	{
		case 0:
			x += 0x80;						// x = x + 0x80
			break;
		case 1:
			x += 0xC0;						// x = x + 0xC0
			break;
		case 2:
			x += 0x94;						// x = x + 0x94
			break;
		case 3:
			x += 0xD4;						// x = x + 0xD4
			break;
	}
	WriteToLcdCtrlRegister(x);
}


// wy�wietla tekst na wsp�rz�dnych x, y
void WriteTextXY(char x, char y, char *S)
{
	while (*S)								// p�tla dzia�a dot�d,a� napotkany zostanie znak ko�ca �a�cuch (/0)
	{
		GotoXY(x, y);						// wyliczenie adresu dla znaku
		LcdWrite(*S);						// wy�wietlenie pojedynczego znaku
		x++; 									// nast�pna pozycja x na ekranie
		S++;									// nast�pna pozycja wska�nika,tzn.nast�pny znak napisu
		if (x > 19)							// je�li x>19 to nast�pna linia
		{
			x = 0; 
			y++;
		}
	}
}


// wy�wietla tekst na wsp�rz�dnych x, y
void WriteText(char *S)
{
	while (*S)								// p�tla dzia�a dot�d,a� napotkany zostanie znak ko�ca �a�cuch (/0)
	{
		LcdWrite(*S);						// wy�wietlenie pojedynczego znaku
		S++;
	}
}


// definiowanie znak�w z tablicy CGRom
void DefineSpecialCharacters(char *ptr)
{
	WriteToLcdCtrlRegister(0x40);		// ustawienie trybu definicji
	while (*ptr != 0)						// p�tla wykonywana do napotkania znaku ko�ca tablicy
	{
		LcdWrite(*ptr);					// zapis znaku do lcd cgram
		ptr++;								// nast�pna pozycja tablicy (wska�nika)
	}
	WriteToLcdCtrlRegister(0x80);		// prze��czenie do trybu wy�wietlania
}

// program g��wny
void main(void)
{
	char ix = 1, iy = 1, x, y, i = 0;
	
	LcdInitialize();
	DefineSpecialCharacters(&CGRom);
	while (1)
	{
		WriteTextXY(x, y, " ");
		if (ix == 1) x++; else x--;
		if (iy == 1) y++; else y--;
		if (x == 19) ix = 0;
		if (x == 0) ix = 1;
		if (y == 3) iy = 0;
		if (y == 0) iy = 1;
		WriteTextXY(x, y, 0x01);
		Delay(50);
	}
}

