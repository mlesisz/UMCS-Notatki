#include "reg51.h"
#include "lcd4b.h"
#include "KBD3x4.h"

//odczyt portu klawiatury
char KBD_Read(char column)
{
	char curr, prev;
	
	KeyPort |= Dummy;					//ustawienie na warto�� "1" bit�w kolumn i wierszy
	KeyPort &= column;				//stan niski kolumny u�ytej jako argument funkcji
	prev = KeyPort;					//odczyt portu klawiatury
	prev &= Row_mask;					//maskowanie wszystkich bit�w opr�cz wierszy
	if (prev == Row_mask) return (0);	//je�li wszystkie bity s� jedynkami dla danej kolumny
											//nie wci�ni�to �adnego klawisza
											
	Delay(50);							//eliminacja drga� styk�w poprzez powt�rny odczyt i por�wnanie
	curr = KeyPort;					//po czasie 50ms
	curr &= Row_mask;
	if (curr == prev) 
	{
		return(~curr);					//zamiana aktywnych bit�w z 0 na 1
	}
	else return(0);					//zwr�� 0 w przypadku r�nic odczyt�w
}


// funkcja odczytuj�ca klawiatur� - matryc� 4 (wiersze) x 3 (kolumny)
// zwracany jest kod wci�ni�tego klawisza
// 0x01  0x02  0x03
// 0x04  0x05  0x06
// 0x07  0x08  0x09
// 0x0A  0x0B  0x0C
char Key_Number(void)
{
	char bx;
	
	bx = KBD_Read(Column_1);		//odczyt: kolumna 1 - wiersz 1, 2, 3, 4
	if (bx)
	{
		if (bx & Row_1) return(0x01);
		if (bx & Row_2) return(0x04);
		if (bx & Row_3) return(0x07);
		if (bx & Row_4) return(0x0A);
	}

	bx = KBD_Read(Column_2);		//odczyt: kolumna 2 - wiersz 1, 2, 3, 4
	if (bx)
	{
		if (bx & Row_1) return(0x02);
		if (bx & Row_2) return(0x05);
		if (bx & Row_3) return(0x08);
		if (bx & Row_4) return(0x0B);
	}

	bx = KBD_Read(Column_3);		//odczyt: kolumna 3 - wiersz 1, 2, 3, 4
	if (bx)
	{
		if (bx & Row_1) return(0x03);
		if (bx & Row_2) return(0x06);
		if (bx & Row_3) return(0x09);
		if (bx & Row_4) return(0x0C);
	}
	
	return(0);							//nie wci�ni�to �adnego klawisza, zwr�� 0
}

 
