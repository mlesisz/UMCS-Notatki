#define KeyPort	P2					//definicja bitu portu klawisza

//sta�e klawiatury
#define Column_1	0xFE				//definicje stan�w bit�w kolumn
#define Column_2	0xFD
#define Column_3	0xFB
#define Dummy		0x7F				//warto�� dla ustawienia bit�w kolumn i wierszy na "1"

#define Row_1		0x40				//definicje po��cze� bit�w wierszy
#define Row_2		0x08
#define Row_3		0x10
#define Row_4		0x20
#define Row_mask	0x78

extern char Key_Number(void);
 
