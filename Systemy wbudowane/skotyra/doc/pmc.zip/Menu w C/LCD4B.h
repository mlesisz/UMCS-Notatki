#define PORT P1
sbit LcdEnable = P3^6;
sbit LcdRead	=	P3^5;
sbit LcdReg	=	P3^4;

// op�nienie oko�o 1 milisekundy dla kwarcu 7,3728MHz
extern void Delay (unsigned int k);
// zapis bajtu do lcd
extern void WriteByteToLcd(char X);
// zapis bajtu do rejestru kontrolnego LCD
extern void WriteToLcdCtrlRegister(char X);
// zapis bajtu do pami�ci obrazu
extern void LcdWrite(char X);
// czyszczenie ekranu LCD
extern void LcdClrScr(void);
// inicjalizacja wy�wietlacza LCD w trybie 4 bity
extern void LcdInitialize(void);
// ustawia kursor na wsp�rz�dnych x,y
extern void GotoXY(char x, char y);
// wy�wietla tekst na wsp�rz�dnych x, y
extern void WriteTextXY(char x, char y, char *S);
// wy�wietla tekst na wsp�rz�dnych x, y
extern void WriteText(char *S);
// definiowanie znak�w z tablicy CGRom
extern void DefineSpecialCharacters(char *ptr);

