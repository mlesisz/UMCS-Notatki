/***********************************************
 demonstracja budowy menu jednopoziomowego
 -----------------------------------------------
 klawiatura matrycowa 4 (wiersze) x 3 (kolumny)
 wy�wietlacz lcd 4 (linie) x 20 (znak�w)
 mikrokontroler AT89S8252 / 7,3728MHz
 ***********************************************/

#pragma SMALL
#include "REG8252.h"
#include "LCD4B.h"
#include "KBD3x4.h"

//typy i sta�e u�ywane przez menu
//uwaga: linie menu maj� maksymaln� d�ugo�� 18 znak�w
//ze wzgl�du na to, �e czasami jedna linia jest wy�wietlana na miejscu drugiej
//powinny one mie� jednakow� (np.uzupe�nion� spacjami) d�ugo��
#define maxoptions 8
#define maxoptlen 18 
#define maxlines 4
typedef struct
{
	char name[maxoptlen];									//napisy menu
	char ptr;													//liczba,kt�r� nale�y doda� do adresu tablicy
	char y0;														//po�o�enie znacznika wyboru w poziomie
} menuitem;

//wykaz opcji menu wraz z po�o�eniem znacznika
code menuitem menus[maxoptions] = {{"opcja 1 . ",0,0},{"opcja 2 ..",0,1},{"opcja 3 . ",0,2},{"opcja 4 ..",0,3},
											  {"opcja 5 . ",1,3},{"opcja 6 ..",2,3},{"opcja 7 . ",3,3},{"opcja 8 ..",4,3}};

//wska�nik do wykazu menu (typ okre�la ilo�� bajt�w podczas inkrementacji wska�nika)
menuitem code *ptrmenus = &menus;

//aktualna pozycja w menu
signed char actpos;


// definicje znak�w specjalnych dla wy�wietlacza LCD
char code CGRom[65] = {	0xAA,0x55,0xAA,0x55,0xAA,0x55,0xAA,0x55,		// "kratka"			0x00
								0xC0,0xC0,0xFF,0xF1,0xF1,0xF1,0xFF,0xC0,		// pusty kwadrat	0x01
							  	0xC0,0xC0,0xFF,0xFF,0xFF,0xFF,0xFF,0xC0,		// kwadrat zacz.	0x02
							  	0xE0,0xFF,0xFF,0xFF,0xE0,0xE0,0xE0,0xE0,		// linia				0x03
							  	0xFF,0xFF,0xF9,0xF3,0xE7,0xF3,0xF9,0xFF,		// znak w lewo		0x04
							  	0xFF,0xFF,0xF3,0xF9,0xFC,0xF9,0xF3,0xFF,		// znak w prawo	0x05
				           	0xFF,0xFF,0xFB,0xF1,0xE4,0xEE,0xFF,0xFF,		// znak w g�r�		0x06
				           	0xFF,0xFF,0xFF,0xEE,0xE4,0xF1,0xFB,0xFF,		// znak w d�		0x07
				           	0x00};

//usuni�cie znacznik�w menu
void Clear_Marks()
{
	ptrmenus = &menus;										//wyznaczenie warto�ci wska�nika do pozycji menu
	ptrmenus += actpos;
	GotoXY(0,ptrmenus->y0);									//usuni�cie lewego znacznika
	LcdWrite(' ');
	GotoXY(19,ptrmenus->y0);								//usuni�cie prawego znacznika
	LcdWrite(' ');
}

//wy�wietlenie menu w/g wykazu (od pozycji wska�nika PTRMENUS liczby linii MAXLINES)
void Display_Menu(void)
{
	char temp;
	code menuitem *ptrtemp;
	
	ptrmenus = &menus;										//wyznaczenie warto�ci wska�nika do aktualnej pozycji menu
	ptrtemp = ptrmenus + actpos;
	ptrmenus += (ptrtemp->ptr);
																	//wy�wietlenie MAXLINES pozycji z tablicy
	for (temp = 0; temp < maxlines; ++temp) WriteTextXY(1, temp, (ptrmenus+temp)->name);
	GotoXY(0,ptrtemp->y0);									//wy�wietlenie lewego znacznika
	LcdWrite(0x05);
	GotoXY(19,ptrtemp->y0);									//wy�wietlenie prawego znacznika
	LcdWrite(0x04);
}

//wy�wietlanie menu na ekranie LCD,reakcja na naciskane klawisze
char Menu(void)
{
	Display_Menu();
	while (1)
	{
		switch (Key_Number())
		{     
			case 0x02:												//klawisz W G�R�
				Clear_Marks();										//usuni�cie znacznik�w wyboru
				if (--actpos < 0) actpos = maxoptions-1;	//wyliczenie aktualnej pozycji w menu
				Display_Menu();									//wy�wietlenie menu z uwzgl�dnieniem zmian
				break;
			case 0x08:												//klawisz W Dӣ
				Clear_Marks();
				if (++actpos >= maxoptions) actpos = 0;
				Display_Menu();
				break;
			case 0x0C:												//klawisz ENTER
				return (actpos);
		}
	}
}


//program g��wny
void main(void)
{
	char temp;
	
	LcdInitialize();
	DefineSpecialCharacters(&CGRom);
	LcdClrScr();
	while(1)
	{
		temp = Menu();
		LcdCLrScr();
		switch (temp)
		{
			case 1:
				//funkcja wywo�ywana dla opcji numer 1
				break;
			case 2:
				//funkcja wywo�ywana dla opcji numer 2
				break;
			case 3:
				//funkcja wywo�ywana dla opcji numer 3
				break;
			case 4:
				//funkcja wywo�ywana dla opcji numer 4
				break;
			case 5:
				//funkcja wywo�ywana dla opcji numer 5
				break;
			case 6:
				//funkcja wywo�ywana dla opcji numer 6
				break;
			case 7:
				//funkcja wywo�ywana dla opcji numer 7
				break;
			case 8:
				//funkcja wywo�ywana dla opcji numer 8
				break;
			default:
				//funkcja wywo�ywana dla opcji numer 9
				break;
		}
	}
}

