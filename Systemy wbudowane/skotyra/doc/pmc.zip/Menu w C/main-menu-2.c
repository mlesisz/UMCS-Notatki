/***********************************************
 demonstracja budowy menu wielopoziomowego
 -----------------------------------------------
 klawiatura matrycowa 4 (wiersze) x 3 (kolumny)
 wy�wietlacz lcd 4 (linie) x 20 (znak�w)
 mikrokontroler AT89S8252 / 7,3728MHz
 ***********************************************/
#pragma SMALL
#include "REG8252.h"
#include "LCD4B.h"
#include "KBD3x4.h"

// definicje znak�w specjalnych dla wy�wietlacza LCD
char code CGRom[65] = {	0xAA,0x55,0xAA,0x55,0xAA,0x55,0xAA,0x55,		// "kratka"			0x00
								0xC0,0xC0,0xFF,0xF1,0xF1,0xF1,0xFF,0xC0,		// pusty kwadrat	0x01
							  	0xC0,0xC0,0xFF,0xFF,0xFF,0xFF,0xFF,0xC0,		// kwadrat zacz.	0x02
							  	0xE0,0xFF,0xFF,0xFF,0xE0,0xE0,0xE0,0xE0,		// linia				0x03
							  	0xFF,0xFF,0xF9,0xF3,0xE7,0xF3,0xF9,0xFF,		// znak w lewo		0x04
							  	0xFF,0xFF,0xF3,0xF9,0xFC,0xF9,0xF3,0xFF,		// znak w prawo	0x05
				           	0xFF,0xFF,0xFB,0xF1,0xE4,0xEE,0xFF,0xFF,		// znak w g�r�		0x06
				           	0xFF,0xFF,0xFF,0xEE,0xE4,0xF1,0xFB,0xFF,		// znak w d�		0x07
				           	0x00};

//typy i sta�e u�ywane przez menu
//uwaga: linie menu maj� maksymaln� d�ugo�� 18 znak�w
//ze wzgl�du na to, �e czasami jedna linia jest wy�wietlana na miejscu drugiej
//powinny one mie� jednakow� (np.uzupe�nion� spacjami) d�ugo��
#define maxoptlen 18 
#define maxlines 4

//definicja dla pozycji pod-menu
typedef struct
{
	char name[maxoptlen];						//napisy menu
	char ptr;										//liczba,kt�r� nale�y doda� do adresu tablicy
	char y0;											//po�o�enie znacznika wyboru w poziomie
	char retval;									//warto�� zwracana w wyniku wyboru
} submenuitem;

//definicja dla pozycji menu g��wnego
typedef struct
{
	char name[maxoptlen];						//napisy menu
	char ptr;										//liczba,kt�r� nale�y doda� do adresu tablicy
	char y0;											//po�o�enie znacznika wyboru w poziomie
	code submenuitem *nextmenu;				//wska�nik do tablicy z wykazem opcji podmenu
	char retval;									//warto�� zwracana w wyniku wyboru
} menuitem;

//wykaz opcji menu wraz z po�o�eniem znacznika, pozycj� wska�nika oraz adresem wykazu pod-menu
code submenuitem menu1[4] = {					//pod-menu 1
{"podmenu 1.1 _ _",0,0,11},{"podmenu 1.2 _  ",0,1,12},{"podmenu 1.3 _ _",0,2,13},
{0,0,0,0}};

code submenuitem menu2[8] = {					//pod-menu 2
{"podmenu 2.1 _ _",0,0,21},{"podmenu 2.2 _  ",0,1,22},{"podmenu 2.3 _ _",0,2,23},
{"podmenu 2.4 _  ",0,3,24},{"podmenu 2.5 _ _",1,3,25},{"podmenu 2.6 _  ",2,3,26},
{"podmenu 2.7 _ _",3,3,27},
{0,0,0,0}};

code submenuitem menu4[3] = {					//pod-menu 3
{"podmenu 4.1 _ _",0,0,41},{"podmenu 4.2 _  ",0,1,42},
{0,0,0,0}};

code submenuitem menu5[4] = {					//pod-menu 4
{"podmenu 5.1 _ _",0,0,51},{"podmenu 5.2 _  ",0,1,52},{"podmenu 5.3 _ _",0,2,53},
{0,0,0,0}};

code menuitem mainmenus[6] = {				//menu g��wne
{"opcja menu g.1 . ",0,0,&menu1,0},{"opcja menu g.2 ..",0,1,&menu2,0},{"opcja menu g.3 . ",0,2,0,3},
{"opcja menu g.4 ..",0,3,&menu4,0},{"opcja menu g.5 . ",1,3,&menu5,0},
{0,0,0,0,0}};

//aktualna pozycja w menu g��wnym
signed char POS_IN_MAINMENU;
//aktualna pozycja w pod-menu
signed char POS_IN_SUBMENU;

//usuni�cie znacznik�w wyboru linii menu
void Clear_Marks(char y)
{
	GotoXY(0,y);
	LcdWrite(' ');
	GotoXY(19,y);
	LcdWrite(' ');
}

//wy�wietlenie menu w/g wykazu (od pozycji wska�nika PTRMENUS liczby linii MAXLINES)
void Display_Sub_Menu(code submenuitem *ptrtable, char num_of_options)
{
	char temp;
	code submenuitem *ptrtemp;
	
	ptrtemp = (ptrtable + POS_IN_SUBMENU);											//ustawienie wska�nika na pozycji,od kt�rej wy�wietlane jest menu
	ptrtable += (ptrtemp->ptr);														//offset wska�nika jest jednym z parametr�w w wykazie menu
	for (temp = 0; (temp < maxlines && temp <= num_of_options); ++temp) WriteTextXY(1, temp, (ptrtable+temp)->name);
	GotoXY(0,ptrtemp->y0);																//wy�wietlenie lewego znacznika (kod 5)
	LcdWrite(0x05);
	GotoXY(19,ptrtemp->y0);																//wy�wietlenie prawego znacznika (kod 4)
	LcdWrite(0x04);
}

//obs�uga pod-menu; jako parametr wywo�ania podawany jest adres tablicy z wykazem menu
char Sub_Menu(code submenuitem *ptrtable)
{
	char maxsubopt = 0;																	//maksymalna (wyliczana) liczba opcji podmenu
	code submenuitem *ptrtemp;                                           //wska�nik pomocniczy

	if (ptrtable->name)																	//wej�cie do obs�ugi,je�li nazwa pod-menu nie jest pusta
	{
		while ((ptrtable+maxsubopt)->name[0]) ++maxsubopt;						//wyznaczenie liczby opcji submenu
		LcdClrScr();																		//czyszczenie ekranu
		POS_IN_SUBMENU = 0;																//pozycja pocz�tkowa w pod-menu
		Display_Sub_Menu(ptrtable,maxsubopt);										//wy�wietlenie pod-menu
		ptrtemp = ptrtable;
		while (1)																			//p�tla niesko�czona-wyj�cie po wybraniu opcji menu
		{
			switch (Key_Number())														//odczyt klawiatury
			{     
				case 0x02:																	//klawisz W G�R�
					Clear_Marks(ptrtemp->y0);											//kasowanie poprzednich znacznik�w wyboru
					if (--POS_IN_SUBMENU < 0) POS_IN_SUBMENU = maxsubopt-1;	//wyznaczenie pozycji w pod-menu i por�wnanie z maksymaln� liczb� opcji
					ptrtemp = ptrtable+POS_IN_SUBMENU;								//wyliczenie wskazania do wybranej pozycji pod-menu
					Display_Sub_Menu(ptrtable,maxsubopt);							//wy�wietlenie pod-menu
					break;
				case 0x08:																	//klawisz W Dӣ
					Clear_Marks(ptrtemp->y0);											//kasowanie poprzednich znacznik�w wyboru
					if (++POS_IN_SUBMENU >= maxsubopt)								//wyznaczenie pozycji w pod-menu i por�wnanie z minimaln� liczb� opcji
					{
						POS_IN_SUBMENU = 0;
						ptrtemp = ptrtable;
					}
					ptrtemp = ptrtable+POS_IN_SUBMENU;								//wyliczenie wskazania do wybranej pozycji pod-menu
					Display_Sub_Menu(ptrtable,maxsubopt);							//wy�wietlenie pod-menu
					break;
				case 0x0C:																	//klawisz ENTER
					return(ptrtemp->retval);
				case 0x0B:																	//klawisz ESC
					return(0);
			}
		}
	} else return(0);
}

//wy�wietlenie menu w/g wykazu (od pozycji wska�nika PTRMENUS liczby linii MAXLINES)
void Display_Main_Menu(code menuitem *ptrtable, char num_of_options)
{
	char temp;
	code menuitem *ptrtemp;
	
	ptrtemp = (ptrtable + POS_IN_MAINMENU);										//ustawienie wska�nika na pozycji,od kt�rej wy�wietlane jest menu
	ptrtable += (ptrtemp->ptr);														//offset wska�nika jest jednym z parametr�w w wykazie menu
	for (temp = 0; (temp < maxlines && temp <= num_of_options); ++temp) WriteTextXY(1, temp, (ptrtable+temp)->name);
	GotoXY(0,ptrtemp->y0);																//wy�wietlenie lewego znacznika (kod 5)
	LcdWrite(0x05);
	GotoXY(19,ptrtemp->y0);																//wy�wietlenie prawego znacznika (kod 4)
	LcdWrite(0x04);
}

//funkcja wy�wietaj�ca menu,zwracany jest bajt kodu wyboru
char Main_Menu(code menuitem *ptrmenus, char maxoptions)
{
	code menuitem *ptrtemp;
	char temp;
	
	POS_IN_MAINMENU = 0;																	//wy�wietlenie menu g��wnego
	Display_Main_Menu(ptrmenus,maxoptions);
	while (1)																				//p�tla niesko�czona-wyj�cie po wybraniu opcji menu
	{
		switch (Key_Number())															//odczyt klawiatury
		{     
			case 0x02:																		//klawisz W G�R�
				Clear_Marks((ptrmenus+POS_IN_MAINMENU)->y0);						//usuni�cie poprzedniego wskazania menu
				if (--POS_IN_MAINMENU < 0) POS_IN_MAINMENU = maxoptions-1;	//wyliczenie pozycji w menu g��wnym,por�wnanie z maks.liczb� opcji
				Display_Main_Menu(ptrmenus,maxoptions);							//wy�wietlenie menu g��wnego
				break;
			case 0x08:																		//klawisz W Dӣ
				Clear_Marks((ptrmenus+POS_IN_MAINMENU)->y0);						//usuni�cie poprzedniego wskazania menu
				if (++POS_IN_MAINMENU >= maxoptions) POS_IN_MAINMENU = 0;	//wyliczenie poz.w menu,por�wnanie z minimaln� liczb� opcji
				Display_Main_Menu(ptrmenus,maxoptions);							//wy�wietlenie menu g��wnego
				break;
			case 0x0C:																		//klawisz ENTER
				ptrtemp = ptrmenus;														//wyliczenie wskazania do pozycji w wykazie odpowiadaj�cej
				ptrtemp += POS_IN_MAINMENU;											//wyborowi
				if (ptrtemp->nextmenu == 0)											//je�li nie ustawiono warto�ci NEXTMENU,to wej�cie do obs�ugi
				{																				//pod-menu
					temp = Sub_Menu(ptrtemp->nextmenu);
					if (temp)																//koniec pracy,je�li zwracana warto�� jest r�na od 0
						return(temp);
					else 
					{
						LcdClrScr();														//naci�ni�to ESC-powr�t do obs�ugi pod-menu
						Display_Main_Menu(ptrmenus,maxoptions);
					}
				}
				else
					return(ptrtemp->retval);											//funkcja po naci�ni�ciu ENTER zwraca jako rezultat swojego 
				break;																		//dzia�ania warto�� zapami�tan� w tablicy-wykazie
		}
	}
}

//program g��wny
void main(void)
{
	LcdInitialize();
	DefineSpecialCharacters(&CGRom);
	LcdClrScr();
	while(1)
	{
		LcdClrScr();
		switch (Main_Menu(&mainmenus, 5))
		{
			case 11:		//<-- pod-menu 1.1
			case 12:		//1.2
			case 13:		//1.3
			case 21:		//2.1
			case 22:		//2.2
			case 23:		//2.3
			case 24:		//2.4
			case 25:		//2.5
			case 26:		//2.6
			case 27:		//2.7
			case 3:		//<-- menu g��wne, opcja 3
			case 41:		//4.1
			case 42:		//4.2
			case 51:		//5.1
			case 52:		//5.2
			case 53:		//5.3
				break;
		}
	}
}

