/* prosty program demonstracyjny "mrugaj�ca dioda"
   dioda LED pod��czona do portu P0.0, stan aktywny = L,
   rezonator kwarcowy 3,6864 MHz */
   
#include <reg51.h>		//do��czenie definicji rejestr�w
								//mikrokontrolera
sbit PortLED = P0^0;		//definicja portu diody LED


//op�nienie oko�o 1 sekundy dla kwarcu 3,6864 MHz
void Delay(unsigned int time)
{
	unsigned int j;
	unsigned char i;
	
	while (time >= 1)		//wykonanie p�tli FOR zajmuje oko�o 1 sek.
	{							//p�tla jest powtarzana TIME razy
		for (i=0; i<3; i++)
			for (j=0; j<52000; j++);
		time--;
	}
}

//pocz�tek programu g��wnego
void main(void)
{
	while (1)				//p�tla niesko�czona
	{
		PortLED = 1;		//zgaszenie diody LED
		Delay(2);			//op�nienie oko�o 2 sek.
		PortLED = 0;		//za�wiecenie LED
		Delay(2);			//op�nienie oko�o 2 sek.
	}
}
 
