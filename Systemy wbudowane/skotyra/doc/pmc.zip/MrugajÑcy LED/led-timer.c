/* prosty program demonstracyjny "mrugaj�ca dioda"
   dioda LED pod��czona do portu P0.0, stan aktywny = L,
   rezonator kwarcowy 3,6864 MHz */
   
#include <reg51.h>		//do��czenie definicji rejestr�w mikrokontrolera

sbit PortLED = P0^0;		//definicja portu diody LED


//op�nienie oko�o 1 sekundy dla kwarcu 3,6864 MHz
void Delay(unsigned int time)
{
	unsigned char i;
	
	for (i=0; i<10; i++)	//p�tla wykonywana 10x, bo podstaw� czasu jest 0,1 sekundy
	{
		TH1 = 0x87;			//wpisanie warto�ci do rejestr�w Timera 1
		TL0 = 0;
		TR1 = 1;				//uruchomienie Timera 1
		while (!TF1);		//oczekiwanie na ustawienie flagi przepe�nienia
		TF1 = 0;				//zerowanie znacznika przepe�nienia Timera 1
	}
	TR1 = 0;					//zatrzymanie Timera 1
}

//pocz�tek programu g��wnego
void main(void)
{
	TMOD = 0x10;			//Timer 1 jako 16-bitowy
	
	while (1)				//p�tla niesko�czona
	{
		PortLED = 1;		//zgaszenie diody LED
		Delay(2);			//op�nienie oko�o 2 sek.
		PortLED = 0;		//za�wiecenie LED
		Delay(2);			//op�nienie oko�o 2 sek.
	}
}
 
