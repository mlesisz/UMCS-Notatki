/*===============================================
 (C) Easy Soft 07/2001
  C code for Programable Signal Controller
 - - - - - - - - - - - - - - - - - - - - - - - -
 Raisonance RC-51, version 6.4.16

 rezonator kwarcowy 22.1184 MHz
 ================================================ */

#pragma SMALL
 
/* definicje rejestr�w 8052 */
#include <reg8252.h>
/* definicje sta�ych u�ywanych w programie */
#include <abs-enkoder.h>

/* przelicznik do zamiany pozycji enkodera na stopnie */
#define FACTOR 11.38

/* 0x00 to adres bazowy wy�wietlacza LCD, nast�pne rejestry umieszczone s� z krokiem 1 */
at 0x00 pdata char LcdCtrlRegister, LcdVideoRam, LcdReadCtrl, LcdRead;

/* adresy poszczeg�lnych kolumn klawiatury */
at 0x34 pdata char Column1;
at 0x2C pdata char Column2;
at 0x1C pdata char Column3;

/* funkcje poszczeg�lnych bit�w portu p2 */
sbit Inp1 = P2^4;				//wej�cia sygna��w
sbit Inp2 = P2^5;
sbit Inp3 = P2^6;
sbit Inp4 = P2^7;

sbit START = P2^3;			//START
sbit KONTROLA = P2^2;		//KONTROLA
sbit DOCISK = P2^1;			//ZWISCHENLUEFTEN
sbit WYJSCIE4 = P2^0;		//AUSGANG 4

sbit NotAus = P1^0;

typedef struct					// definicja typu rekordu do zapami�tywania nastaw
{
	char Number;
	signed char Tune;
	int E1_1,E2_1,E3_1,E4_1,E1_2,E2_2,E3_2,E4_2;
	int A1_1,A2_1,A3_1,A4_1,A1_2,A2_2,A3_2,A4_2;
} Settings;
data Settings BUF;			// bufor nastaw
char PRG;						// numer aktualnego programu maszyny
unsigned int POS;				// pozycja enkodera w kodzie graya
int ZERO = 0;					// korekta ustawie� enkodera (w stopniach)




/******************************* FUNKCJE ZEWN�TRZNE W ASSEMBLERZE ******************************************/
/* odczyt statusu rekordu w eeprom */
extern bit EE_PosActive(unsigned int ADDRESS);

/* odczyt bajtu z eeprom */
extern char EE_GetByte(unsigned int ADDRESS);

/* zapis bajtu do eeprom */
extern void EE_StoreByte(char B, unsigned int ADDRESS);

/* zapis obszaru pami�ci w eeprom pod @address do @address+count */
extern void EE_SaveBUF(unsigned int ADDRESS, char COUNT);

/* odczyt obszaru pami�ci z eeprom do ram spod adresu @address do @address+count */
extern void EE_ReadBUF(unsigned int ADDRESS, char COUNT);

/* odczyt pozycji enkodera (w j�zyku asm ze wzgl�du na zakres cz�stotliwo�ci pracy,sygn.zegarowy od 100kHz
   linia P1.2 - dane, P1.3 - zegar dla enkodera  */
extern unsigned int PositionRead(void);



/******************************* POZOSTA�E FUNKCJE W J�ZYKU C **********************************************/
/* inicjalizacja rekordu zawieraj�cego pozycje za��cze� / wy��cze� */
void InitializeBUF(void)
{
	BUF.Number = 0xFF; BUF.Tune = 0;
	BUF.E1_1 = BUF.E2_1 = BUF.E3_1 = BUF.E4_1 = BUF.E1_2 = BUF.E2_2 = BUF.E3_2 = BUF.E4_2 = 999;
	BUF.A1_1 = BUF.A2_1 = BUF.A3_1 = BUF.A4_1 = BUF.A1_2 = BUF.A2_2 = BUF.A3_2 = BUF.A4_2 = 999;
}


unsigned int Gray2Bin(unsigned int N)
{
	char i;
	unsigned int A = N;
	
	for (i = 1; i != 13; i++) N = N^(A >> i);
	
	return (N);
}


/* zamiana absolutnej pozycji enkodera na stopnie */
unsigned int DPE(void)
{
	int N;
	
	N = Gray2Bin(PositionRead());
	N = N / FACTOR;
//	N = N - ZERO;
	N = 359 - N - ZERO;
   if (N < 0) N = N + 360;
	return(N);
}


/* funkcja realizuje op�nienie k*1ms dla rezonatora f=11.0592 MHz */
void delay (unsigned int k) 
{
	unsigned int i,j;
	for ( j = 0; j < k; j++)
		for (i = 0; i <= 148;) {
			i++;
		}
}


/* oczekiwanie na potwierdzenie gotowo�ci przez wy�wietlacz LCD */
void LcdWait (void) 
{
	while (LcdReadCtrl & 0x80);
}


/* zapis bajtu do rejestru kontrolnego wy�wietlacza LCD */
void WriteToLcdCtrlRegister(char X) 
{
	LcdCtrlRegister = X;
	LcdWait();
}


/* zapis bajtu do pami�ci obrazu wy�wietlacza LCD */
void LcdWrite(char X) 
{
	LcdVideoRam = X;
	LcdWait();
}


/* kasowanie ekranu LCD */
void LcdClrScr(void) 
{
	LcdCtrlRegister = 0x01;
	LcdWait();
}


/* inicjalizacja wy�wietlacza w trybie 8-bit�w */
void LcdInitialize(void) 
{
	delay(15);
	LcdCtrlRegister = 0x30;
	delay(10);
	LcdCtrlRegister = 0x30;
	delay(10);
	WriteToLcdCtrlRegister(0x30);
	WriteToLcdCtrlRegister(0x3C);
	WriteToLcdCtrlRegister(0x08);
	WriteToLcdCtrlRegister(0x01);
	WriteToLcdCtrlRegister(0x06);
	WriteToLcdCtrlRegister(0x0C);
}

	
/* ustawienie kursora na wsp�rz�dnych x,y wy�wietlacza LCD */
void GotoXY(char x, char y) 
{
	char addr;
	
	switch (y) {
		case 0:
			addr = 0x80+x;
			break;
		case 1:
			addr = 0xC0+x;
			break;
		case 2:
			addr = 0x94+x;
			break;
		case 3:
			addr = 0xD4+x;
			break;
	}
	LcdCtrlRegister = addr;
	LcdWait();
}


/* rysowanie poziomej linii */
void LcdLine(char y)
{
	char x = 0;
	
	GotoXY(x,y);
	for (x = 0; x<20; x++) LcdWrite(0x07);
}


/* wy�wietlenie napisu na wsp�rz�dnych x,y */
void WriteTextXY(char x, char y, char code *S) 
{
	while (*S) {
		GotoXY(x, y);
		LcdWrite(*S);
		x++; 
		S++;
		if (x > 19) {
			x = 0; 
			y++;
		}
	}
}


/* zapis definicji znak�w do pami�ci ram LCD */
void DefineSpecialCharacters(char *ptr) 
{
	LcdCtrlRegister = 0x40;		// set cgram definition mode
	LcdWait();
	while (*ptr != 0x00) {
		LcdWrite(*ptr);
		ptr++;
	}
	LcdCtrlRegister = 0x80;		// switch to normal mode
	LcdWait();
}


/* odczyt klawiatury, funkcja zwraca numery klawiszy wymienione na pocz�tku programu w klauzuli define */
char KeyRead(void)
{
	char curr, next;
	
	curr = Column3;				// pierwsza kolumna klawiatury
	if (curr != 0xFF) {
		delay(30);
		next = Column3;
		if (curr == next) {
			if (next == _ArrowUp_) return(ArrowUp);
			if (next == _ArrowDown_) return(ArrowDown);
			if (next == _ArrowLeft_) return(ArrowLeft);
			if (next == _ArrowRight_) return(ArrowRight);
			if (next == _Enter_) return(Enter);
			if (next == _Speichern_) return(Save);
			if (next == _Lesen_) return(Read);
		}
	}	
	
	curr = Column1;				// trzecia kolumna klawiatury
	if (curr != 0xFF) {
		delay(30);
		next = Column1;
		if (curr == next) {
			if (next == _Aus1_1_) return(Aus1_1);
			if (next == _Aus2_1_) return(Aus2_1);
			if (next == _Aus3_1_) return(Aus3_1);
			if (next == _Aus4_1_) return(Aus4_1);
			if (next == _Aus1_2_) return(Aus1_2);
			if (next == _Aus2_2_) return(Aus2_2);
			if (next == _Aus3_2_) return(Aus3_2);
			if (next == _Aus4_2_) return(Aus4_2);
		}
	}	
	
	curr = Column2;				// druga kolumna klawiatury
	if (curr != 0xFF) {
		delay(30);
		next = Column2;
		if (curr == next) {
			if (next == _Ein1_1_) return(Ein1_1);
			if (next == _Ein2_1_) return(Ein2_1);
			if (next == _Ein3_1_) return(Ein3_1);
			if (next == _Ein4_1_) return(Ein4_1);
			if (next == _Ein1_2_) return(Ein1_2);
			if (next == _Ein2_2_) return(Ein2_2);
			if (next == _Ein3_2_) return(Ein3_2);
			if (next == _Ein4_2_) return(Ein4_2);
		}
	}

	return(0);
}


/* ustawia / kasuje znak wyboru na pozycji menu w zale�no�ci od parametru mode (=Set,=Clear) */
void SetSign(char Y, char mode) 
{
	char left = 0x20, right = 0x20;
	
	if (mode == Set) {
		left = 2;
		right = 1;
	}
	GotoXY(0,Y); 
	LcdWrite(left);
	GotoXY(19,Y); 
	LcdWrite(right);
}
	

/* przekszta�cenie warto�ci char na �a�cuch liczbowy */
void DisplayDegree(char x, char y, int N) 
{
	int l=0, D;
	
	if (N > 359) {
		WriteTextXY(x, y, "---");
	} else {
		GotoXY(x, y);
		if (N < 0) {							// wy�wietlenie znaku minus i zamiana na liczbe >0
			LcdWrite(0x2D);
			N = -N;
		}
		D = N;
		if (N >= 100) {
			l = D/100;
			LcdWrite(l+0x30);					// liczba + kod znaku "0" - 100
			D = D - 100*l;
		}
		if (N >= 10) {
			l = D/10;
			LcdWrite(l+0x30);					// 10
			D = D - 10*l;
		}
		l = D;
		LcdWrite(l+0x30);						// 1
		LcdWrite(0xDF);
		LcdWrite(0x20);
	}
}


/* wy�wietlenie numeru programu */
void DisplayProgramNum(char x, char y, char n) 
{
	GotoXY(x, y);
	if ((n / 10) > 0) {
		LcdWrite((n / 10) + 0x30);
		GotoXY(x+1, y);
		LcdWrite((n - 10 * (n / 10)) + 0x30);
	} 
	else {
		LcdWrite(n + 0x30);
		GotoXY(x+1, y);
		LcdWrite(0x20);
	}
}


/* wy�wietla list� nastaw od numeru N do N+3 ale nie wi�cej ni� 8*/
void DisplayList(char n, char arrowlinenum)
{
	char y;
	
	for (y = 0; y<3; y++) {
		switch (y+n) {
		case 1:
			WriteTextXY(0, y+1, " Start      /     ");
			DisplayDegree(7, y+1, BUF.E1_1);
			DisplayDegree(13, y+1, BUF.A1_1);
			break;
		case 2:
			WriteTextXY(0, y+1, " Lueft      /     ");
			DisplayDegree(7, y+1, BUF.E2_1);
			DisplayDegree(13, y+1, BUF.A2_1);
			break;
		case 3:
			WriteTextXY(0, y+1, " Kontr      /     ");
			DisplayDegree(7, y+1, BUF.E3_1);
			DisplayDegree(13, y+1, BUF.A3_1);
			break;
		case 4:
			WriteTextXY(0, y+1, " Ausg4      /     ");
			DisplayDegree(7, y+1, BUF.E4_1);
			DisplayDegree(13, y+1, BUF.A4_1);
			break;
		case 5:
			WriteTextXY(0, y+1, " Eing1      /     ");
			DisplayDegree(7, y+1, BUF.E1_2);
			DisplayDegree(13, y+1, BUF.A1_2);
			break;
		case 6:
			WriteTextXY(0, y+1, " Eing2      /     ");
			DisplayDegree(7, y+1, BUF.E2_2);
			DisplayDegree(13, y+1, BUF.A2_2);
			break;
		case 7:
			WriteTextXY(0, y+1, " Eing3      /     ");
			DisplayDegree(7, y+1, BUF.E3_2);
			DisplayDegree(13, y+1, BUF.A3_2);
			break;
		case 8:
			WriteTextXY(0, y+1, " Eing4      /     ");
			DisplayDegree(7, y+1, BUF.E4_2);
			DisplayDegree(13, y+1, BUF.A4_2);
			break;
		case 9:
		case 10:
		case 11:
			WriteTextXY(0, y+1, " - - - - - - - - -");
			break;
		}
	}
	GotoXY(0,arrowlinenum);
	LcdWrite(0x02);					// strza�ka w prawo
}


// etykietka trybu Automatik
void BetriebScr(void)
{
	LcdClrScr();
	LcdLine(0);
	WriteTextXY(2,0,"Automatikbetrieb");
	WriteTextXY(0,1,"Programm-Nr");
	DisplayProgramNum(12,1,PRG);
	WriteTextXY(0,2,"Winkelgrad IST");
//	WriteTextXY(0,3,"Drehzahl");
}


/* zatrzymanie maszyny na skutek b��du wej�cia */
void InpError(char CODE)
{
	NotAus = 0;
	LcdClrScr();
	WriteTextXY(0, 0, "Eingang ");
	LcdWrite(0x30 + CODE);
	WriteTextXY(0, 1, "Bitte ENTER druecken");
	while (KeyRead() != Enter);
	BetriebScr();
	NotAus = 1;
}


/* testowanie warunku za��czenia / wy��czenia sygna�u */
char Range(unsigned int within, unsigned int from, unsigned int upto)
{
	if (from <= upto)
		if ((within >= from) && (within <= upto)) return(1); else return(0);
	else 
		if (within >= from) return(1); else	
			if (within >= upto) return(0); else return(1);
}


/* testowanie po�o�enia enkodera i akcja zale�na od niego */
void TestPosition(unsigned int RAD)
{
	P2 = (P2 | 0xF0);
	if (Range(RAD,BUF.E1_1,BUF.A1_1)) START = 0; else START = 1;
	if (Range(RAD,BUF.E2_1,BUF.A2_1)) DOCISK = 0; else DOCISK = 1;
	if (Range(RAD,BUF.E3_1,BUF.A3_1)) KONTROLA = 0; else KONTROLA = 1;
	if (Range(RAD,BUF.E4_1,BUF.A4_1)) WYJSCIE4 = 0; else WYJSCIE4 = 1;
	Inp1 = 1;
	if (Range(RAD,BUF.E1_2,BUF.A1_2) && Inp1) InpError(1);
	Inp2 = 1;
	if (Range(RAD,BUF.E2_2,BUF.A2_2) && Inp2) InpError(2);
	Inp3 = 1;
	if (Range(RAD,BUF.E3_2,BUF.A3_2) && Inp3) InpError(3);
	Inp4 = 1;
	if (Range(RAD,BUF.E4_2,BUF.A4_2) && Inp4) InpError(4);
}


/* zapis zmiennej BUF do eeprom */
void BUF2EEPROM(char PROGNUM)
{
	unsigned int ADDRESS = PROGNUM * sizeof(BUF) + 3;
	
	LcdClrScr();
	WriteTextXY(3, 1, "Bitte warten!");
	BUF.Number = PRG;
	EE_SaveBUF(ADDRESS, sizeof(BUF));
}


/* odczyt zmiennej BUF z eeprom */
void EEPROM2BUF(char PROGNUM)
{
	unsigned int ADDRESS = PROGNUM * sizeof(BUF) + 3;
	
	LcdClrScr();
	WriteTextXY(3, 1, "Czekaj prosze");
	if (EE_PosActive(ADDRESS))	EE_ReadBUF(ADDRESS, sizeof(BUF)); else {
		InitializeBUF();
		BUF.Number = PRG;
	}
}


/* PSC jest w trybie BETRIEB. Jest to normalny tryb pracy */
void ModeBetrieb(void) 
{
	int degree = 0;
	
	BetriebScr();
	while ((P3 & 0x38) == KeyInBetrieb) {
		degree = DPE();
		TestPosition(degree);
		DisplayDegree(15,2,degree);
	}
} 


void WaitInLesenMode(void)
{
	LcdClrScr();		// wy�wietlenie informacji o numerze aktualnej wersji
	LcdLine(0);
	WriteTextXY(3,0,"Tryb wyboru");
	WriteTextXY(0,1,"Numer aktywnego     Programu");
	DisplayProgramNum(7,2,PRG);
	WriteTextXY(0,3,"Dalej = Read");
	while ((KeyRead() == 0) & ((P3 & 0x38) == KeyInLesen));	// wej�cie do menu dopiero po naci�ni�ciu klawisza
	while (KeyRead() == Read);
}

/* odczyt nastaw z wewn�trznej pami�ci eeprom 
   BUF ma rozmiar 34 bajt�w, tote� w pami�ci eeprom 2kB mo�na zmie�ci� 
   60 nastaw,adresy 0x0000,0x0001,0x0002 - zaj�te s� przez zmienne systemowe, 
   od adresu 0x0003 zaczyna si� zapis nastaw */
void ModeLesen(void)
{
	char key = 0;
	signed char pos = 0;

	WaitInLesenMode();
	
	delay(300);
	LcdClrScr();
	if ((P3 & 0x38) == KeyInLesen) {
		WriteTextXY(0,0,"Programm-Nummer     auswaehlen mit TasteLESEN");
		WriteTextXY(3,3,"Programm-Nr");
		GotoXY(1,3); LcdWrite(0x01);		// wy�wietlenie znaku "w lewo"
		GotoXY(18,3); LcdWrite(0x02);		// wy�wietlenie znaku "w prawo"
		while (key != Read) {
			key = KeyRead();
			switch (key) {
				case ArrowUp:
				case ArrowRight:
					pos++;
					break;
				case ArrowDown:
				case ArrowLeft:
					pos--;
					break;
			}
			if (pos < 0) pos = 59;
			if (pos > 59) pos = 0;
			DisplayProgramNum(15,3,pos);
			if (EE_PosActive(pos * sizeof(BUF) + 3)) WriteTextXY(0, 3, "*"); else WriteTextXY(0, 3, " ");
			delay(200);
		}
		if (EE_PosActive(pos * sizeof(BUF) + 3)) {
			PRG = pos;
			EE_StoreByte(PRG,0x0000);		// zapis aktywnego programu do zmiennych syst.
			EEPROM2BUF(PRG);					// odczyt wskazanego programu z eeprom
		}
		WaitInLesenMode();
	}
}


/* wy�wietlenie opisu po wci�ni�ciu klawisza */
void DisplayDesc(char N) 
{
	WriteTextXY(0,2,"Ein:      Aus:     ");
	switch (N) {
		case 1:
		case 2:
			WriteTextXY(0,1,"Ausgang 1(Start)  ");
			DisplayDegree(4,2,BUF.E1_1);
			DisplayDegree(14,2,BUF.A1_1);
			WriteTextXY(0,3,"                  ");
			delay(1000);
			break;
		case 3:
		case 4:
			WriteTextXY(0,1,"Ausgang 2(DOCISK)");
			DisplayDegree(4,2,BUF.E2_1);
			DisplayDegree(14,2,BUF.A2_1);
			WriteTextXY(0,3,"                  ");
			delay(1000);
			break;
		case 5:
		case 6:
			WriteTextXY(0,1,"Ausgang 3(Kontroll");
			DisplayDegree(4,2,BUF.E3_1);
			DisplayDegree(14,2,BUF.A3_1);
			WriteTextXY(0,3,"                  ");
			delay(1000);
			break;
		case 7:
		case 8:
			WriteTextXY(0,1,"Ausgang 4         ");
			DisplayDegree(4,2,BUF.E4_1);
			DisplayDegree(14,2,BUF.A4_1);
			WriteTextXY(0,3,"                  ");
			delay(1000);
			break;
		case 9:
		case 10:
			WriteTextXY(0,1,"Ueberwachung Eing1");
			DisplayDegree(4,2,BUF.E1_2);
			DisplayDegree(14,2,BUF.A1_2);
			WriteTextXY(0,3,"                  ");
			delay(1000);
			break;
		case 11:
		case 12:
			WriteTextXY(0,1,"Ueberwachung Eing2");
			DisplayDegree(4,2,BUF.E2_2);
			DisplayDegree(14,2,BUF.A2_2);
			WriteTextXY(0,3,"                  ");
			delay(1000);
			break;
		case 13:
		case 14:
			WriteTextXY(0,1,"Ueberwachung Eing3");
			DisplayDegree(4,2,BUF.E3_2);
			DisplayDegree(14,2,BUF.A3_2);
			WriteTextXY(0,3,"                  ");
			delay(1000);
			break;
		case 15:
		case 16:
			WriteTextXY(0,1,"Ueberwachung Eing4");
			DisplayDegree(4,2,BUF.E4_2);
			DisplayDegree(14,2,BUF.A4_2);
			WriteTextXY(0,3,"                  ");
			delay(1000);
			break;
	}
}


/* ustawienie pozycji zero enkodera */
void SetZeroPos(void) 
{
	int degree;
	char p;
	
	LcdClrScr();
	WriteTextXY(0,0,"Winkelgrad IST ");
	WriteTextXY(0,1,"Kurbelwelle auf OT  stellen und 0-Punkt festlegen");
	while (KeyRead() != Save) {		// p�tla zako�czona przez wci�ni�cie Save
		degree = Gray2Bin(PositionRead()) / FACTOR;	// wy�wietlana pozycja musi by� absolutna tzn.bez korekty
		DisplayDegree(15,0,degree);
		delay(10);
	}
	while (KeyRead() == Save);		// oczekiwanie na zwolnienie klawisza
	ZERO = degree;
	p = ZERO  >> 8;							// zapami�tanie nastaw w eeprom
	EE_StoreByte(p, 0x01);
	p = ZERO & 0x00FF;
	EE_StoreByte(p, 0x02);
	LcdClrScr();
}


/* skorygowanie po�o�enia punktu zerowego */
void ZeroPosChange(void)
{
	char x;
	int *p;
	
	LcdClrScr();							// wy�wietlenie ekranu menu
	LcdLine(0);
	WriteTextXY(4, 0, " Korrektur ");
	WriteTextXY(0, 1, "Winkelgrad IST");
	GotoXY(18, 3);
	LcdWrite(0x01); LcdWrite(0x02);
	p = &BUF.E1_1;							// przeliczenie warto�ci w BUF, *p wskazuje na elementy tablicy
	for (x = 0; x <= 15; x++) {		// wracamy do warto�ci sprzed KORREKTUR
		if (*p < 360) {
			*p = *p - BUF.Tune;
			if (*p < 0) *p = *p + 360;
		}
		p++;
	}
	do {
		x = KeyRead();
		switch (x) {
			case ArrowRight:
				if (BUF.Tune < 15) BUF.Tune++;
				break;
			case ArrowLeft:
				if (BUF.Tune > -15) BUF.Tune--;
				break;
		}
		DisplayDegree(15, 1, BUF.Tune);
		delay(200);
	} while (x != Save);
	while (KeyRead() == Save);	// czekamy na zwolnienie Save
	LcdClrScr();
	
	p = &BUF.E1_1;							// przeliczenie warto�ci w BUF, *p wskazuje na elementy tablicy
	for (x = 0; x <= 15; x++) {
		if (*p != 360) {
			*p = *p + BUF.Tune;
			if (*p > 359) *p = *p - 360;
			if (*p < 0) *p = *p + 360;
		}
		p++;
	}
	LcdClrScr();
	WriteTextXY(0, 0, "Save mit Taste Save,abbrechen mit Taste Read");
	do {
		x = KeyRead();
	} while ((x != Save) && (x != Read));
	if (x == Save) BUF2EEPROM(PRG);	// zapami�tanie BUF
	LcdClrScr();
}


/* r�czne wprowadzanie stopni w trybie nauki */
void ByDegree(void) 
{
	char stop = 0, key, y0, y1;
	signed int degree = 0;
	
	y0 = y1 = 1;
	LcdClrScr();
	WriteTextXY(0,0,"Winkelgrad IST ");
	GotoXY(18,3); LcdWrite(0x01);		// wy�wietlenie znaku "w lewo"
	LcdWrite(0x02);						// wy�wietlenie znaku "w prawo"
	while (stop == 0) {
		key = KeyRead();
		switch (key) {
			case ArrowLeft:			// strza�ka w lewo, zmniejszanie k�ta
				degree--;
				break;
			case ArrowRight:			// strza�ka w prawo, zwi�kszanie k�ta
				degree++;
				break;
			case ArrowUp:
				if (y1 > 1) {
					y1--;
					y0 = 6;
				} else 
					if (y0 > 1) y0--;
				break;
			case ArrowDown:
				if (y1 < 3) {
					y1++;
					y0 = 1;
				} else
					if (y0 < 6) y0++;
				break;
			case Aus1_1:
				BUF.A1_1 = degree;
				DisplayDesc(1);
				y0 = y1 = 1;
				START = 1;
				while (KeyRead() == Aus1_1);
				break;
			case Ein1_1:
				BUF.E1_1 = degree;
				DisplayDesc(2);
				y0 = y1 = 1;
				START = 0;
				while (KeyRead() == Ein1_1);
				break;
			case Aus2_1:
				BUF.A2_1 = degree;
				DisplayDesc(3);
				y0 = 1; y1 = 2;
				DOCISK = 1;
				while (KeyRead() == Aus2_1);
				break;
			case Ein2_1:
				BUF.E2_1 = degree;
				DisplayDesc(4);
				y0 = 1; y1 = 2;
				DOCISK = 0;
				while (KeyRead() == Ein2_1);
				break;
			case Aus3_1:
				BUF.A3_1 = degree;
				DisplayDesc(5);
				y0 = 1; y1 = 3;
				KONTROLA = 1;
				while (KeyRead() == Aus3_1);
				break;
			case Ein3_1:
				BUF.E3_1 = degree;
				DisplayDesc(6);
				y0 = 1; y1 = 3;
				KONTROLA = 0;
				while (KeyRead() == Ein3_1);
				break;
			case Aus4_1:
				BUF.A4_1 = degree;
				DisplayDesc(7);
				y0 = 2; y1 = 3;
				WYJSCIE4 = 1;
				while (KeyRead() == Aus4_1);
				break;
			case Ein4_1:
				BUF.E4_1 = degree;
				DisplayDesc(8);
				y0 = 2; y1 = 3;
				WYJSCIE4 = 0;
				while (KeyRead() == Ein4_1);
				break;
			case Aus1_2:
				BUF.A1_2 = degree;
				DisplayDesc(9);
				y0 = 3; y1 = 3;
				while (KeyRead() == Aus1_2);
				break;
			case Ein1_2:
				BUF.E1_2 = degree;
				DisplayDesc(10);
				y0 = 3; y1 = 3;
				while (KeyRead() == Ein1_2);
				break;
			case Aus2_2:
				BUF.A2_2 = degree;
				DisplayDesc(11);
				y0 = 4; y1 = 3;
				while (KeyRead() == Aus2_2);
				break;
			case Ein2_2:
				BUF.E2_2 = degree;
				DisplayDesc(12);
				y0 = 4; y1 = 3;
				while (KeyRead() == Ein2_2);
				break;
			case Aus3_2:
				BUF.A3_2 = degree;
				DisplayDesc(13);
				y0 = 5; y1 = 3;
				while (KeyRead() == Aus3_2);
				break;
			case Ein3_2:
				BUF.E3_2 = degree;
				DisplayDesc(14);
				y0 = 5; y1 = 3;
				while (KeyRead() == Ein3_2);
				break;
			case Aus4_2:
				BUF.A4_2 = degree;
				DisplayDesc(15);
				y0 = 6; y1 = 3;
				while (KeyRead() == Aus4_2);
				break;
			case Ein4_2:
				BUF.E4_2 = degree;
				DisplayDesc(16);
				y0 = 6; y1 = 3;
				while (KeyRead() == Ein4_2);
				break;
			case Save:
				stop = 0x01;
				while (KeyRead() == Save);
				break;
		}
		delay(200);
		if (degree < 0) degree = 360;
		if (degree > 360) degree = 0;
		DisplayDegree(15,0,degree);
		DisplayList(y0, y1);
	}
}

/* odczyt i zapami�tanie pozycji po�o�enia ko�a maszyny */
void ByWheel(void) 
{
	char stop = 0, key, y0, y1;
	signed int degree = 0;
	
	y0 = y1 = 1;
	LcdClrScr();
	WriteTextXY(0,0,"Winkelgrad IST ");
	while (stop == 0) {
		key = KeyRead();
		switch (key) {
			case ArrowUp:
				if (y1 > 1) {
					y1--;
					y0 = 6;
				} else 
					if (y0 > 1) y0--;
				break;
			case ArrowDown:
				if (y1 < 3) {
					y1++;
					y0 = 1;
				} else
					if (y0 < 6) y0++;
				break;
			case Aus1_1:
				BUF.A1_1 = degree;
				DisplayDesc(1);
				y0 = y1 = 1;
				START = 1;
				while (KeyRead() == Aus1_1);
				break;
			case Ein1_1:
				BUF.E1_1 = degree;
				DisplayDesc(2);
				y0 = y1 = 1;
				START = 0;
				while (KeyRead() == Ein1_1);
				break;
			case Aus2_1:
				BUF.A2_1 = degree;
				DisplayDesc(3);
				y0 = 1; y1 = 2;
				DOCISK = 1;
				while (KeyRead() == Aus2_1);
				break;
			case Ein2_1:
				BUF.E2_1 = degree;
				DisplayDesc(4);
				y0 = 1; y1 = 2;
				DOCISK = 0;
				while (KeyRead() == Ein2_1);
				break;
			case Aus3_1:
				BUF.A3_1 = degree;
				DisplayDesc(5);
				y0 = 1; y1 = 3;
				KONTROLA = 1;
				while (KeyRead() == Aus3_1);
				break;
			case Ein3_1:
				BUF.E3_1 = degree;
				DisplayDesc(6);
				y0 = 1; y1 = 3;
				KONTROLA = 0;
				while (KeyRead() == Ein3_1);
				break;
			case Aus4_1:
				BUF.A4_1 = degree;
				DisplayDesc(7);
				y0 = 2; y1 = 3;
				WYJSCIE4 = 1;
				while (KeyRead() == Aus4_1);
				break;
			case Ein4_1:
				BUF.E4_1 = degree;
				DisplayDesc(8);
				y0 = 2; y1 = 3;
				WYJSCIE4 = 0;
				while (KeyRead() == Ein4_1);
				break;
			case Aus1_2:
				BUF.A1_2 = degree;
				DisplayDesc(9);
				y0 = 3; y1 = 3;
				while (KeyRead() == Aus1_2);
				break;
			case Ein1_2:
				BUF.E1_2 = degree;
				DisplayDesc(10);
				y0 = 3; y1 = 3;
				while (KeyRead() == Ein1_2);
				break;
			case Aus2_2:
				BUF.A2_2 = degree;
				DisplayDesc(11);
				y0 = 4; y1 = 3;
				while (KeyRead() == Aus2_2);
				break;
			case Ein2_2:
				BUF.E2_2 = degree;
				DisplayDesc(12);
				y0 = 4; y1 = 3;
				while (KeyRead() == Ein2_2);
				break;
			case Aus3_2:
				BUF.A3_2 = degree;
				DisplayDesc(13);
				y0 = 5; y1 = 3;
				while (KeyRead() == Aus3_2);
				break;
			case Ein3_2:
				BUF.E3_2 = degree;
				DisplayDesc(14);
				y0 = 5; y1 = 3;
				while (KeyRead() == Ein3_2);
				break;
			case Aus4_2:
				BUF.A4_2 = degree;
				DisplayDesc(15);
				y0 = 6; y1 = 3;
				while (KeyRead() == Aus4_2);
				break;
			case Ein4_2:
				BUF.E4_2 = degree;
				DisplayDesc(16);
				y0 = 6; y1 = 3;
				while (KeyRead() == Ein4_2);
				break;
			case Save:
				stop = 0x01;
				while (KeyRead() == Save);
				break;
		}
		degree = DPE();
		DisplayDegree(15,0,degree);
		delay(200);
		DisplayList(y0, y1);
	} 
}


/* zapisanie danych do eeprom dla okre�lonego numeru programu - potwierdzenie
   "Save", rezygnacja "Read" */
void WantToSave(void)
{
	char key = 0, pos = PRG;
	
	LcdClrScr();
	while (KeyRead() == Save);		// czekamy na zwolnienie Save
	WriteTextXY(0, 0, "Save mit Taste Save,abbrechen mit Taste Read");
	WriteTextXY(3,3,"Programm-Nr");
	GotoXY(1,3); LcdWrite(0x01);			// wy�wietlenie znaku "w lewo"
	GotoXY(18,3); LcdWrite(0x02);			// wy�wietlenie znaku "w prawo"
	do {											// wyb�r numeru programu,pod kt�rym zapisujemy
		key = KeyRead();
		switch (key) {
			case ArrowUp:
			case ArrowRight:
				pos++;
				break;
			case ArrowDown:
			case ArrowLeft:
				pos--;
				break;
		}
		if (pos < 0) pos = 59;
		if (pos > 59) pos = 0;
		DisplayProgramNum(15,3,pos);
		if (EE_PosActive(pos * sizeof(BUF) + 3)) WriteTextXY(0, 3, "*"); else WriteTextXY(0, 3, " ");
		delay(200);
	} while ((key != Read) && (key != Save));
	if (key == Save) {
		if (!(EE_PosActive(pos * sizeof(BUF) + 3))) BUF.Tune = 0;	//je�li nowy program,to <<KORREKTUR = 0 Grade>>
		PRG = pos;
		EE_StoreByte(PRG,0x0000);		// zapis aktywnego programu do zmiennych syst.
		BUF2EEPROM(PRG);
	}
	LcdClrScr();
}


/* PSC jest w trybie nauki, mo�e si� "uczy�" poprzez wprowadzanie r�czne stopni lub poprzez
 zapami�tywanie po�o�enia enkodera (pokr�canie ko�em maszyny) */
void ModeLernen(void) 
{
	char K;
	signed char iy = 0;
	
	LcdClrScr();
	while ((P3 & 0x38) == KeyInLernen) {
		WriteTextXY(1,0,"Tasteneingabe   ");			// wy�wietlenie menu trybu nauki
		WriteTextXY(1,1,"Teachin-Eingabe ");
		WriteTextXY(1,2,"0-Punkt eingaben");
		WriteTextXY(1,3,"Korrektur       ");
		SetSign(iy,Set);						// ozn.aktualnej pozycji (Set oznacza za�.,Clear-kasowanie znacznika)
		K = KeyRead();
		if (K != 0) {
			delay(100);
			SetSign(iy,Clear);
			switch (K) {
				case ArrowUp:					// strza�ka w g�r�, ruch znacznika w g�r�
					iy--; 
					break;

				case ArrowDown:				// strza�ka w d�, ruch znacznika w d�
					iy++; 
					break;
				
				case Enter:						// naci�ni�to enter, wyb�r opcji
					switch (iy) {
						case 0:
							ByDegree();			// ustawianie r�czne stopni
							P2 = (P2 | 0x0F);	// wy��czenie led po programowaniu
							WantToSave();
							break;
						case 1:
							ByWheel();			// kr�cenie enkoderem i ustawianie
							P2 = (P2 | 0x0F);	// wy��czenie led po programowaniu
							WantToSave();
							break;
						case 2:
							SetZeroPos();		// ustawienie pozycji zero enkodera
							break;
						case 3:
							ZeroPosChange();	// korekta o +/- 15 stopni
							break;
					}
				break;
			} 
  			if (iy < 0) iy = 3;
			if (iy > 3) iy = 0;
		}
	}
}


// program g��wny 
void main(void)
{
	char i = 0, mode;
	
	PRG = EE_GetByte(0x00);
	ZERO = (EE_GetByte(0x0001) << 8) | (EE_GetByte(0x0002));
	
	if (PRG == 0xFF) {
		PRG = 0x00;						// ustaw domy�lny numer programu
		EE_StoreByte(PRG, 0x00);	// i zapami�taj go
		ZERO = 0x0000;					// ustaw domy�lne po�o�enie enkodera
		EE_StoreByte(0x00, 0x01);	// i zapami�taj je
		EE_StoreByte(0x00, 0x02);
		InitializeBUF();				// zainicjuj nastawy
		BUF.Number = PRG;				// zapami�taj domy�lny numer programu
		BUF2EEPROM(PRG);				// zapami�taj w eeprom
	}
	
	EEPROM2BUF(PRG);					// odczyt nastaw z eeprom
	LcdInitialize();					// inicjowanie wy�wietlacza lcd (tryb 8-bit�w)
	P1 = 0xE4;							// ustawienie pocz�tkowych stan�w port�w
	P2 = 0xFF;

	DefineSpecialCharacters(CGRom1);		// definiowanie znak�w w/g wzorca zawartego w CGRom1
	NotAus = 1;							// wyj�cie NotAus - przeka�nik dorobiony w czasie wizyty 23/02
	while (i != 80) {
		LcdWrite(0xFF);
		i++;
	}
	delay(500);
	LcdClrScr();
	WriteTextXY(0,0,"PS-CONTROLLER 2000  ver.1,2 dd.2001/11");
	delay(2000);
	LcdClrScr();
	while ((P3 & 0x38) == 0x38) WriteTextXY(0,0,"Betriebsart waehlen!");

	LcdClrScr();
	
	while (1) {
		mode = (P3 & 0x38);		// p3.3=Read, p3.4=lehren, p3.5=betrieb (active is low!!)
		if (mode == KeyInLernen) ModeLernen(); else
			if (mode == KeyInLesen) ModeLesen(); else
				if (mode == KeyInBetrieb) ModeBetrieb();
	}
}


