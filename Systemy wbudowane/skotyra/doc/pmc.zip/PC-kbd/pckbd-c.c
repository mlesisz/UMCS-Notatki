/***********************************
 Odczyt klawiatury PC
 (C) Easy Soft 04/2002
 ***********************************
 RAISONANCE RC-51
 ***********************************/
#pragma SMALL
#include "lcd4b.h"

// definicje znak�w specjalnych dla wy�wietlacza LCD
char code CGRom[65] = {	0xAA,0x55,0xAA,0x55,0xAA,0x55,0xAA,0x55,		// "kratka"			0x00
								0xC0,0xC0,0xFF,0xF1,0xF1,0xF1,0xFF,0xC0,		// pusty kwadrat	0x01
							  	0xC0,0xC0,0xFF,0xFF,0xFF,0xFF,0xFF,0xC0,		// kwadrat zacz.	0x02
							  	0xE0,0xFF,0xFF,0xFF,0xE0,0xE0,0xE0,0xE0,		// linia				0x03
							  	0xFF,0xFF,0xF9,0xF3,0xE7,0xF3,0xF9,0xFF,		// znak w lewo		0x04
							  	0xFF,0xFF,0xF3,0xF9,0xFC,0xF9,0xF3,0xFF,		// znak w prawo	0x05
				           	0xFF,0xFF,0xFB,0xF1,0xE4,0xEE,0xFF,0xFF,		// znak w g�r�		0x06
				           	0xFF,0xFF,0xFF,0xEE,0xE4,0xF1,0xFB,0xFF,		// znak w d�		0x07
				           	0x00};

//bity statusu
bit Alt, Caps, Ctrl, CapsLock, Extended, Pause;
//status.0 = Scroll Lock, status.1=NumLock, status.2=CapsLock
char status = 0x02;

//bufor wci�ni�tego klawisza
char key;

//do r�nych operacji
char temp, temp1;



//wys�anie bajtu do klawiatury
extern void TX_byte(char x);
//odbi�r bajtu z klawiatury
extern char RX_byte(void);


//ustawienie statusu klawiatury
//x.0-scroll lock, x.1-num lock, x.2-caps lock
void Kbd_status(char x)
{
	TX_byte(0xED);
	RX_byte();
	TX_byte(x);
	RX_byte();
}


//konwersja bajtu na warto�� hex,wy�wietlenie na LCD
//przyk�ad procedury do interpratacji znak�w odebranych z klawiatury
char Hex2Ascii(char x)
{
	if (x < 10) x += 0x30; else x += 0x37;
	return(x);
}


void WriteKeyCode(char x)
{
	if (x != 0)
	{
		WriteTextXY(0,1,"k.code:");
		if (Extended) WriteText("0xE0,");
		WriteText("0x");
		LcdWrite(Hex2Ascii(x / 16));
		LcdWrite(Hex2Ascii(x % 16));
		GotoXY(0,2);
		if (Caps) WriteText("Shift ");
		if (Ctrl) WriteText("Ctrl ");
		if (Alt) WriteText("Alt");
		if (Pause) WriteTextXY(0,3,"Paused "); else WriteTextXY(0,3,"       ");
	} 
	else
	{
		WriteTextXY(7,1,"            ");
		WriteTextXY(0,2,"                   ");
	}

	
}


//program g��wny
void main(void)
{
	Delay(250);
	LcdInitialize();
	DefineSpecialCharacters(&CGRom);
	LcdClrScr();
	
												//reset klawiatury;po "reset" klawiatura odpowiada wysy�aj�c 2 kody
	TX_byte(0xFF);							//pierwszy z nich to 0xFA, drugi 0xAA
	while (!(RX_byte() == 0xFA && RX_byte() == 0xAA));

												//napis oznaczaj�cy,�e inicjacja klawiatury by�a pomy�lna
	WriteTextXY(0,0,"Init OK! Welcome...");
	WriteTextXY(0,1,"k.code:");

	Kbd_status(status);					//za��czenie num lock

	while (1)								//g��wna p�tla (niesko�czona) programu
	{
		key = RX_byte();
		if (key == 0xE0)					//kody rozszerzone
		{
//---------- 0xE0 ----------------------
			key = RX_byte();
			switch (key)
			{
				case 0x14:							//R-Ctrl
					Ctrl = 1;
					key = 0;
					break;
				case 0x11:							//R-Alt
					Alt = 1;
					key = 0;
					break;
				case 0x1F:							//L-GUI
				case 0x27:							//R-GUI
				case 0x2F:							//Apps.
				case 0x70:							//Insert
				case 0x6C:							//Home
				case 0x7D:							//PgUp
				case 0x71:							//Delete
				case 0x69:							//End
				case 0x7A:							//PgDn
				case 0x75:							//Arrow Up
				case 0x6B:							//Arrow Left
				case 0x72:							//Arrow Down
				case 0x74:							//Arrow Right
				case 0x5A:							//Keypad-ENTER
				case 0x4A:							//Keypad-divide /
				case 0x37:							//Power
				case 0x3F:							//Sleep
				case 0x5E:							//Wake up
					Extended = 1;
					break;
				case 0xF0:							//odebrano BREAK "rozszerzonego" klawisza
					key = RX_byte();				//trzeba odebra� bajt i "zgubi�" go
					if (key == 0x11) Alt = 0;			//R-Alt
					else 
						if (key == 0x14) Ctrl = 0;		//R-Ctrl
					key = 0;
					Extended = 0;
					break;
			} //switch
		} //if (key == 0xE0)

//---------- default -------------------
		else if (key != 0xE0 && key != 0xF0 && key != 0xE1)
		{
			Extended = 0;
			switch (key)
			{
				case 0x12:							//L-Shift
				case 0x59:							//R-Shift
					Caps = 1;
					key = 0;
					break;
				case 0x58:							//Caps Lock
					CapsLock = !CapsLock;
					status ^= 0x04;
					Kbd_status(status);
					key = 0;
					break;
				case 0x14:							//L-Ctrl
					Ctrl = 1;
					key = 0;
					break;
				case 0x11:							//L-Alt
					Alt = 1;
					key = 0;
					break;
				case 0x77:							//Num Lock
					status ^= 0x02;
					Kbd_status(status);
					key = 0;
					break;
				case 0x7E:							//Scroll Lock
					status ^= 0x01;
					Kbd_status(status);
					key = 0;
					break;
			} //switch 
		} //else

//---------- pause ---------------------
		else if (key == 0xE1)					//klawisz Pause ma bardzo d�ug� sekwencj� i nie ma kodu BREAK
		{												//0xE1 0x14 0x77 0xE1 0xF0 0x14 0xF0 0x77
			RX_byte();
			RX_byte();
			RX_byte();
			RX_byte();
			RX_byte();
			RX_byte();
			RX_byte();
			key = 0x77;
			Pause = !Pause;
		}
		
//---------- break ---------------------
		if (key == 0xF0)					//odebrano BREAK "standardowego" klawisza
		{												//wystarczy odebra� i "zgubi�" kod zwolnionego klawisza
			key = RX_byte();
			switch (key)
			{
				case 0x12:							//L-Shift
				case 0x59:							//R-Shift
					Caps = 0;
					break;
				case 0x14:							//L-Ctrl
					Ctrl = 0;
					break;
				case 0x11:							//L-Alt
					Alt = 0;
					break;
			}
			key = 0;
		} //if (key == 0xF0)

		WriteKeyCode(key);
	} //while (1)
}


