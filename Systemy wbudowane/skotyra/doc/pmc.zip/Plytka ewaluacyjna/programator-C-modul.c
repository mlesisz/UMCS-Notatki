/* ============================
  Programator SPI, ver.2
  ----------------------------
  (C)05/2003 Jacek Bogusz
=============================== */
 
#pragma DEFJ(TIM1_INIT=0xFD)				//timer 1 jako pr�dko�� transmisji (19200,n,8,1)
													//dla rezonatora 11,0592MHz TH1=0xFD; dla 7,3728MHz TH1 = 0xFE
#pragma TINY									//wyb�r modelu pami�ci programu

#include <stdio.h>							//funkcje wej�cia - wyj�cia
#include <reg51.h>							//definicje rejestr�w

#define	S1200		0x12						//definicje sygnatur uk�ad�w
#define	S1200D	0x13
#define	S2313A	0x20
#define	S4414A	0x28
#define	S8515A	0x38
#define	S2323A	0x48
#define	S2343A	0x4C
#define	S2333A	0x34
#define	S4433A	0x30
#define	S4434		0x6C
#define	S8535		0x68
#define	m83		0x65
#define	m161		0x60
#define	m163		0x64
#define	m603		0x42
#define	m103		0x41
#define	S8252		0x86

char device;									//identyfikator programowanego uk�adu
unsigned int addr;							//adres s�owa w flash / eeprom

sbit greenled = P3^5;						//dioda zielona "ok"
sbit redled = P3^4;							//dioda czerwona "fault"
sbit yellowled = P3^7;						//dioda ��ta "read/write"
sbit resettype = P1^5;						//port wyboru fazy sygna�u "reset"

extern bit RESET;								//zewn�trzne deklaracje linii steruj�cych SPI
extern bit MOSI;
extern bit MISO;
extern bit SCK;

bit deviceset;									//czy ustawiony jest typ programowanego uk�adu?
bit resetph;


//******* funkcje zewn�trzne, w module ASM ********

//zapis bajtu poprzez spi, bajt do zapisu w byte
extern void wrser(char byte);

//odczyt bajtu poprzez spi, bajt zwracany przez warto�� funkcji
extern char rdser();

//p�tla zajmuj�ca uK na wielokrotno�� oko�o k milisekund dla rezonatora 11,0592MHz
extern void delayms(char msec);


//w�asna implementacja funkcji putchar (dla ka�dego 0x0A oryginalny putchar dodaje 0x0D)
int putchar (const int c)
{
	SBUF = c;
	TI = 0;
	while (!TI);
}


//funkcja zwraca m�odszy bajt zmiennej typu int
char lsb(unsigned int x)
{
	return((char)(x));
}


//funkcja zwraca starszy bajt zmiennej typu int
char msb(unsigned int x)
{
	return((char)(x>>8));
}


//"efekty" �wietlne - za��czenie i wy��czenie diod LED
void led_init()
{
	greenled = 0;			 					//za�wiecenie diod LED po starcie
	redled = 0;
	yellowled = 0;
	delayms(0xFF);
	redled = 1;									//zgaszenie diody czerwonej
	delayms(0xFF);
	greenled = 1;								//zgaszenie diody ��tej
	delayms(0xFF);
	yellowled = 1;								//zgaszenie diody zielonej
	delayms(0xFF);
}


//wystawienie sygna�u reset dla programowanego uK, faza reset zale�y od stanu resetph ustawianego wraz z typem uk�adu
//resetph=1 -> AT90, resetph=0 -> AT89; reset programowanego uK aktywny tzn.uK nie pracuje
void set_reset()
{
	RESET = resetph;
}


//reset programowanego uK nieaktywny tzn.uK pracuje
void clr_reset()
{
	RESET = !resetph;
}


//procedura obs�ugi przerwania INT0
//wystawienie sygna�u reset dla programowanego uK
void int0(void) interrupt 0
{
	set_reset();								//reset aktywny
	delayms(0xFF);
	clr_reset();								//reset nieaktywny
}


//wys�anie kodu b��du do programatora
void put_err()
{
	putchar(0x3F);
}


//wys�anie kodu CR do programatora
void put_ret()
{
	putchar(0x0D);
}


//zapis "serial programming enable"
void spiinit()
{
	char temp = 32;
	
	clr_reset();								//reset nieaktywny 
	EA = 0;										//blokowanie przyjmowania przerwa� przez uk�ad programatora
	SCK = 0;										//ustawienie linii zegarowej SCK na 0
	delayms(50);
	set_reset();								//reset aktywny
	delayms(50);								//op�nienie oko�o 50ms
	wrser(0xAC);								//SPI, zapis bajtu 1
	wrser(0x53);								//SPI, zapis bajtu 2
	if ((device >= S2313A) && (device <= 0x7F))
	{
		do											//synchronizacja spi; dop�ki SPI nie pracuje synchronicznie nie jest mo�liwy zapis danych 
		{											//do uk�adu; sygnalizacja synchr.nast�puje podczas zapisu 3 bajtu - wypr.jest w�wczas 0x53
			if (rdser() == 0x53) break;	//odczyt/zapis bajtu 3
			wrser(0x00);						//SPI, zapis bajtu 4 dla uk�ad�w innych ni� 89S8252 
			wrser(0xAC);						//SPI, zapis bajtu 1
			wrser(0x53);						//SPI, zapis bajtu 2
		} while (--temp);
	}
	else
	{
		temp = rdser();
	}
	if (device != S8252) 					//dla uk�ad�w innych ni� 89S8252 konieczny
	{												//zapis bajtu 4
		wrser(0x00);
	}
}


//procedura pomocnicza do odczytu sygnatury uk�adu
void w17call(char param1)
{
	wrser(0x30);
	wrser(0x00);
	wrser(param1);
	putchar(rdser());
}


//procedura pomocnicza dla funkcji zapisu bajtu (C, c)
//dla ATMega delay wynosi 0, pozosta�e oko�o 8ms
void writeflashdelay()
{
	if ((device != m103)&&(device != m83)&&(device != m603)&&(device != m161)&&(device != m163)) delayms(3);
	put_ret();
}


//program g��wny
void main ()
{
	char temp, temp1, cmd1, cmd2, cmd3;
	
	putchar(0x0A);
	
	PCON |= 0x80;									//ustawienie bitu prescalera zegara transmisji
	IE |= 0x81;										//w��czenie przerwa� i zezwolenie na przyjmowanie przerwa� z int0

	resetph = resettype;
	RESET = resetph;								//reset mikrontrolera docelowego
	led_init();										//zgaszenie diod led
	RESET = !resetph;								//normalna praca
	
	while (1)
	{
		while ((temp = _getkey()) == 0x1B);
		switch (temp)
		{
			case 'T':								//'T' ustawianie typu urz�dzenia
				device = _getkey();
				if ((device == S1200)||(device == S1200D)||(device == S2313A)||(device == S4414A)||(device == S8515A)||(device == S2323A)||
					 (device == S2343A)||(device == S2333A)||(device == S4433A)||(device == S4434)||(device == S8535)||(device == m83)||
					 (device == m161)||(device == m163)||(device == m603)||(device == m103)||(device == S8252)) deviceset = 1;
//				if (device == S8252) resetph = 1; else resetph = 0;
				put_ret();
				break;

			case 'S':								//'S' pytanie o rodzaj pod��czonego programatora
				putchar('A');
				putchar('V');
				putchar('R');
				putchar(' ');
				putchar('D');
				putchar('E');
				putchar('V');
				break;

			case 'V':								//'V' pytanie o wersj� programu
				putchar('7');
				putchar('0');
				break;

			case 'v':								//'v' pytanie o wersj� urz�dzenia
				putchar('1');
				putchar('0');
				break;

			case 't':								//'t' pytanie o obs�ugiwane uk�ady
				putchar(S1200);					//AT90S1200-rev.C
				putchar(S1200D);					//AT90S1200-rev.D
				putchar(S2313A);					//AT90S2313
				putchar(S4414A);					//AT90S4412
				putchar(S8515A);					//AT90S8515
				putchar(S2323A);					//AT90S2323
				putchar(S2343A);					//AT90S2343
				putchar(S2333A);					//AT90S2333
				putchar(S4433A);					//AT90S4433
				putchar(S4434);					//AT90S4434
				putchar(S8535);					//AT90S8535
				putchar(m83);						//ATMega 83
				putchar(m161);						//ATMega 161
				putchar(m163);						//ATMega 163
				putchar(m603);						//ATMega 603
				putchar(m103);						//ATMega 103
				putchar(S8252);					//AT89S8252
				putchar(0x00);
				redled = 1;							//ew.zgaszenie diody czerwonej
				greenled = 0;						//za�wiecenie diody zielonej
				break;

			case 'p':								//'p' pytanie o rodzaj programatora
				putchar('S');
				break;

			case 'a':								//'a' pytanie o mo�liwo�� autoinkrementacji adresu
				putchar('Y');
				break;

			case 'x':								//'x' polecenie za��czenia diody led
				switch (cmd1 = _getkey())
				{
					case 0x00:
						redled = 0;					//LED b��d
						greenled = 1;
						yellowled = 1;
						break;
					case 0x01:
						greenled = 0;				//LED OK
						yellowled = 1;
						redled = 1;
						break;
					case 0x02:
						yellowled = 0;				//LED zapis/odczyt
						greenled = 1;
						redled = 1;
						break;
				}
				put_ret();
            break;

			case 'y':								//'y' polecenie wy��czenia diody led
				switch (cmd1 = _getkey())
				{
					case 0x00:
						redled = 1;					//b��d
						break;
					case 0x01:
						greenled = 1;				//OK
						break;
					case 0x02:
						yellowled = 1;				//zapis/odczyt
						break;
				}
				put_ret();
				break;

			case 'P': case 'C': case 'R': case 'A': case 'D':	//przed wykonaniem tych operacji 
			case 'd': case 'L': case 'e': case 'I': case 's':	//wymagane jest,aby by� ustawiony typ uk�adu!!!
			case 'm': case ':': case '.': case 'c':
				if (!deviceset) put_err(); else 
				switch (temp)
				{
					case 'P':						//'P' tryb programowania
						spiinit();
						delayms(10);
						put_ret();
						break;

					case 'C':						//'C' zapis pami�ci programu, MSB
						if (device == S8252)
						{
							put_err();
						}
						else
						{
							temp1 = _getkey();		//odczyt bajtu z UART
							wrser(0x48);				//zapis SPI, bajt komendy
							wrser(msb(addr));			//adres, MSB
							wrser(lsb(addr));			//adres, LSB
							wrser(temp1);				//dane
							writeflashdelay();		//oczekiwanie na flash
							addr++;
						}
						break;

					case 'c':						//'c' zapis pami�ci programu, LSB
						temp1 = _getkey();		//odczyt bajtu z UART
						if (device == S8252)
						{
							cmd1 = (msb(addr)<<3) | 0x02;
						}
						else
						{
							wrser(0x40);
							cmd1 = msb(addr);
						}
						wrser(cmd1);				//zapis SPI, bajt 1
						wrser(lsb(addr));
						wrser(temp1);
						writeflashdelay();
						if (device == S8252) addr++;
						break;
						

					case 'R':						//'R' odczyt obszaru pami�ci programu
						if (device == S8252)
						{
							cmd1 = (msb(addr)<<3) | 0x01;
						}
						else
						{
							wrser(0x28);
							cmd1 = msb(addr);
						}
						wrser(cmd1);
						wrser(lsb(addr));
						putchar(rdser());
						if (device != S8252)
						{
							wrser(0x20);
							wrser(msb(addr));
							wrser(lsb(addr));
							putchar(rdser());
						}
						addr++;
						break;

					case 'A':						//'A' za�aduj adres
						addr = _getkey();
						cmd1 = _getkey();
						addr = (addr<<8) | cmd1;
						put_ret();
						break;

					case 'D':						//'D' zapis pami�ci eeprom (danych)
						temp1 = _getkey();
						if (device == S8252)
						{
							cmd1 = ((msb(addr)<<3) & 0x38) | 0x06;
						}
						else
						{
							wrser(0xC0);
							cmd1 = msb(addr);
						}
						wrser(cmd1);
						wrser(lsb(addr));
						wrser(temp1);
						delayms(10);
						put_ret();
						addr++;
						break;

					case 'd':						//'d' odczyt pami�ci eeprom (danych)
						if (device == S8252)
						{
							cmd1 = ((msb(addr)<<3) & 0x38) | 0x05;
						}
						else
						{
							wrser(0xA0);
							cmd1 = msb(addr);
						}
						wrser(cmd1);
						wrser(lsb(addr));
						putchar(rdser());
						addr++;
						break;

					case 'L':						//'L' opuszczenie trybu programowania
						P1 = 0xFF;					//ustawienie trybu pracy wyprowadze� programatora jako wej�ciowe
						clr_reset();				//normalna praca - reste uk�. programowanego nieaktywny
						EA = 1;						//za��czenie przyjmowania przerwa� przez uk�ad programatora
						delayms(10);
						put_ret();
						break;

					case 'e':						//'e' kasowanie uk�adu
						wrser(0xAC);
						if (device != S8252) wrser(0x80);
						wrser(0x04);
						wrser(0x00);
						delayms(50);
						put_ret();
						break;

					case 'l':						//'l' zapis bit�w blokujacych
						temp1 = _getkey();
						wrser(0xAC);
						if (device == S8252)
						{
							temp1 &= 0x07;
							wrser(temp1);
						}
						else
						{
							temp1 &= 0x06;
							temp1 |= 0xE0;
							wrser(temp1);
							wrser(0x00);
						}
						wrser(0x00);
						delayms(20);
						put_ret();
						break;

					case 's':						//'s' odczyt sygnatury uk�adu
						if (device == S8252)
						{
							put_err();
						}
						else
						{
							w17call(0x02);
							w17call(0x01);
							w17call(0x00);
						}
						break;

					case 'm':						//'m' zapis strony pami�ci programu
						wrser(0x4C);
						wrser(msb(addr));
						wrser(lsb(addr));
						wrser(0x00);
						delayms(10);
						put_ret();
						break;

					case ':':						//':' komenda uniwersalna
						cmd1 = _getkey();
						cmd2 = _getkey();
						cmd3 = _getkey();
						wrser(cmd1);
						wrser(cmd2);
						wrser(cmd3);
						putchar(rdser());
						delayms(10);
						put_ret();
						break;

					case '.':						//'.' nowa komenda uniwersalna
						cmd1 = _getkey();
						cmd2 = _getkey();
						cmd3 = _getkey();
						temp1 = _getkey();
						wrser(cmd1);
						wrser(cmd2);
						wrser(cmd3);
						wrser(temp1);
						putchar(rdser());
						delayms(10);
						put_ret();
						break;
					
					case 'Z':						//'Z' komenda testuj�ca
						cmd1 = _getkey();
						cmd2 = _getkey();
						wrser(cmd1);
						wrser(cmd2);
						putchar(rdser());
						break;
				} //2-nd case			
		}//1-st case
	}//of while(1)
}//of main program

