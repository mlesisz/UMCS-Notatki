#include <reg51.h>
#include <stdio.h>
#include <lcd4b.h>


// zamiana funkcji putchar()
// oryginalnie funkcja PUTCHAR wykorzystuje tylko rejestr R7 i akumulator
// je�li poni�sza u�ywa czego� wi�cej - mo�e nie funkcjonowa� 
// nale�y uwa�nie przygl�da� si� rejestrom
int putchar ( const int c )
{
	LcdWrite(c);
	return (0);
}

void main (void)
{
//inicjalizacja LCD w trybie 4 bity
	LcdInitialize();
	LcdClrScr();
//zamiana liczby 123 na warto�� szesnastkow�
	printf("%s%04X%s","123 Dec.to ",123," Hex");
//koniec programu
	while (1);
}
