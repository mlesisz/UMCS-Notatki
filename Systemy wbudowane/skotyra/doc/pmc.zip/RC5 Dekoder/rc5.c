/**********************************************************
 Dekoder kodu RC5 odbieranego z toru podczerwieni
 na podstawie materia��w zamieszczonych na stronie:
 http://www.ustr.net/infrared/infrared1.shtml
 ----------
 UWAGI n/t wykonania:
 Wej�cie odbiornika podczerwieni pod��czone jest do wej�cia
 przerwania INT0 (P3.2). Dekoder u�ywa Timer'a 0 do pomiaru
 czasu trwania bit�w. Aplikacja wykonana by�a w oparciu o
 mikrokontroler AT89C2051 z rezonatorem kwarcowym 12MHz.
***********************************************************/ 

#include  "reg51.h"


#define IE0_VECTOR 1					//numer wektora przerwania INT0
#define TF0_VECTOR 2					//numer wektora przerwania Timer'a 0

#define BYTE unsigned char   
#define WORD unsigned int
#define ENABLE 1
#define DISABLE 0

#define HighB(value) ((value >> 8) & 0xFF)
#define LowB(value)  (value & 0xFF)

#define RELOAD        -440			//czas RELOAD dobrany dla nadajnika EasyTip1 
#define FIRST_RELOAD  -870			//Code718 i rezonatora 12 MHZ 

#define _TOGGLE      0x80
#define _START2      0x40
#define _START1      0x20      

sbit clockline = P3^7;				//linia zegara zapisu do uk�ad�w zewn�trznych

typedef struct _BYTE
{
	BYTE b3;								//bardziej znacz�cy bajt
	BYTE b2;
	BYTE b1;
	BYTE b0;								//mniej znacz�cy bajt
}BYTES;

typedef union _LONGINT
{
	unsigned long l;					//unia umo�liwiaj�ca szybk� konwersj�
	BYTES  b;							//zmiennej typu longint na pojedyncze
}LONGUNION;								//bajty i odwrotnie (bajty na longint)


//zmienne globalne
bit	bRC5valid;						//bit znacznika ustawiany po odberaniu
											//1-go kodu RC5

BYTE  command;							//odebrana komenda
BYTE  subaddress;						//odebrany adres urz�dzenia

BYTE  slopecount;						//licznik pomocniczy
LONGUNION shiftreg;					//rejestr przesuwny dla odebranego s�owa RC5


/****************************************************************
 Obs�uga przerwania od odbiornika RC5. Rozpoczyna ona
 pomiary odbieranego sygna�u przez Timer 0
 ****************************************************************/
void RC5_StartIrq(void) interrupt IE0_VECTOR
{
   EX0 = DISABLE;						//wy��czenie przerwa� od INT0
   slopecount = 27;					//odbierane jest 27 pr�bek
   TH0 = HighB(RELOAD);				//nastawa Timer'a 0
   TL0 = LowB(RELOAD);
   TR0 = ENABLE;						//uruchomienie Timer'a 0 w celu pomiaru
   TF0 = 0;								//czasu trwania bitu
   ET0 = ENABLE;						//uruchomienie obs�ugi przerwania Timer'a 0
}


/**************************************************************
 Obs�uga przerwania Timer'a 0. Po odebraniu 27 par bit�w 
 przesuwaj�cy zawiera warto�� RC5 a stan bitu bRC5Valid zmieniany
 jest na "1"
 **************************************************************/
void TimingIrq(void) interrupt TF0_VECTOR using 1
{
	bit bLevel;

   bLevel = P3^2;						//testowanie stanu wej�cia P3.2
   while (slopecount--)				//do odebrania 27 pr�bek
   {
   	TR0 = DISABLE;					//zatrzymanie Timer'a 0
		TH0 = HighB(FIRST_RELOAD);	//za�adowanie nowej warto�ci dla reload
		TL0 = LowB (FIRST_RELOAD);
		TR0 = ENABLE;					//uruchomienie Timer'a 0
		if (bLevel)						//dodanie odczytanego poziomu do warto�ci
		{									//rejestru przesuwnego
			shiftreg.b.b0 = shiftreg.b.b0 | 1; 
		}
		shiftreg.l = shiftreg.l << 1;
		return;       
	}
	TR0 = DISABLE;         			//zatrzymanie Timer'a 0
	ET0 = DISABLE;         			//wy��czenie przerwa� od Timer'a 0
	bRC5valid = 1;	      			//ustawienie bitu sygnalizacji, �e
											//bufor zawiera odebran� transmisj� RC5
}


/*******************************************************
 Dekodowanie odebranej warto�ci (wydzielenie adresu i
 komendy). Funkcja zwraca "1" je�li dekodowanie przebieg�o
 bezb��dnie, inaczej zwracane jest "0"
 *******************************************************/
bit DecodeRC5Code(void)
{
	BYTE i, b;

	command = subaddress = 0;		//zerowanie adresu urz�dzenia i kodu komendy
	shiftreg.l = shiftreg.l >> 1;

	for (i=0; i < 6 ; i ++)			//najpierw dekodowanie 6 bit�w komendy
	{  
		b = shiftreg.b.b0 & 0x03;
		if(b == 0x02) command |= 0x40; 
			else if(b == 0x01) command &= ~0x40; 
				else return(0);
		command = command >> 1;
		shiftreg.l = shiftreg.l >> 2;
	}

	for (i=0;i < 5;i++)				//nast�pnie dekodowanie 5 bit�w adresu
	{
		b = shiftreg.b.b0 & 0x03;
		if(b == 0x02)subaddress = subaddress | 0x20;
			else if(b == 0x01) subaddress &= ~0x20;
				else return(0);  
		subaddress = subaddress >> 1;
		shiftreg.l = shiftreg.l >> 2;
   }

	b = shiftreg.b.b0 & 0x03; 
   if(b == 0x02)command |= _TOGGLE;
   	else if(b == 0x01)command &= ~_TOGGLE;
   		else return(0);  

   shiftreg.l = shiftreg.l >> 2;
   b = shiftreg.b.b0 & 0x03;			//bit synchronizacji numer 2 inwersja
   if(b==0x02) command &= ~_START2;	//dla 7-bitowych komend (extended RC5)
   	else if(b == 0x01) command |= _START2;
			else return(0);
  
	shiftreg.l = shiftreg.l >> 2;
	b=shiftreg.b.b0 & 0x03;				//bit synchronizacji numer 1
	if(b == 0x02) subaddress |= _START1;
		else if(b==0x01) subaddress = subaddress & ~_START1;
			else return(0);  

   return(1);								//sygnalizacja, �e odbi�r poprawny
}


/*******************************************************
 Program g��wny jako przyk�ad aplikacji wysy�aj�cej
 odebran� komend� i adres przez port P0
 *******************************************************/

//impuls zapisujacy dane w uk�adzie zewn�trznym
//(opadaj�ce zbocze sygna�u)
void Clock()
{
	clockline = 0;
	clockline = 0;
	clockline = 1;
}


void main(void)
{
	clockline = 1;							//stan spoczynkowy sygna�u zegarowego
   TMOD = 0x11;							//nastawa trybu pracy Timer'�w 0 i 1
												//oba pracuj� w trybie Timer 16-bitowy                                                          
	EX0 = ENABLE;							//za��czenie przerwa� INT0 wyzywalanych
	IE0 = 0;									//opadaj�cym zboczem sygna�u
	IT0 = ENABLE;

	shiftreg.l = 0x02;					//inicjowanie warto�ci bufora odbioru
	EA = ENABLE;							//za��czenie przerwa�

	while (1)
   {
		if (bRC5valid)						//je�li odebrano poprawn� transmisj� RC5
		{
			bRC5valid=0;
			if (DecodeRC5Code())			//testowanie bufora odbioru, dekodowanie 
			{									//adresu i komendy
				P1 = subaddress;
				Clock();
				P1 = command;
				Clock();
			} 
			shiftreg.l=0x02;				//restart dekodera
			IE0 = 0;
			EX0 = ENABLE;        
		}
	}
}
 
