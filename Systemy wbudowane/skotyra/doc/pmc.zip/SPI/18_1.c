#include <reg8252.h>

unsigned char spistatus;		//zmienna pomocnicze
sbit	SS = P1^4; 			//linia portu sygna�u SS

//obs�uga przerwania interfejsu SPI (23H)
void SPI_Irq(void) interrupt 5
{
	spistatus = 0;
}

//inicjowanie trybu master interfejsu SPI
void SPI_Master(void)
{
	while (SS != 1);		//oczekiwanie na zwolnienie linii SS
	SPCR = 0xF8;			//ustalenie trybu pracy SPI
}

//wys�anie bajtu przez interfejs SPI
void SPI_Send(unsigned char x)
{
SPIE = SPE = 0;		//wy��czenie przyjmowania przerwa�
SPI_Master();			//ustalenie trybu master dla SPI
SS = 0;				//zerowanie linii wyboru slave SS
spistatus = 1;			//znak nie zosta� wys�any
SPIE = SPE = 1;		//zezwol.na przyjmowanie przerwa�
SPDR = x;			//zapis bajtu do rejestru danych SPI
while (spistatus == 1);	//oczekiwanie na zako�czenie wysy�ki
				//bajtu danych
}
