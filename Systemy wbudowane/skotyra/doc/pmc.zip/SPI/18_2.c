#include <reg8252.h>

sbit SS = P1^4;			//deklaracja linii SS
unsigned char counter;			//licznik odebranych bajt�w
unsigned char buferror;		//b��d przepe�nienia bufora SPI
unsigned char idata bufor[20];	//bufor odebranych znak�w
unsigned char ptr = *bufor;		//wska�nik do bufora

//procedura obs�ugi przerwania interfejsu SPI (23H) napisana tylko jako
//przyk�ad programowania! 
void SPI_Irq(void) interrupt 5
{
	ptr* = SPDR;			//zapis odebranego znaku do bufora
	ptr++;				//nast�pna pozycja
					//b��d, gdy odebrano za du�o znak�w
	if (counter++ >20) buferror = 1;
}

//ustawienie trybu slave dla SPI
void SPI_Slave(void);
{
	SPCR = 0xE8;			//bit MSTR = 0
}

//odbi�r znak�w
void SPI_Receive(void)
{
	SPIE = SPE = 0;		//wy��czenie przyjmowania przerwa�
	buferror = counter = 0;	//kasowanie licznika oraz wsk.b��du
	ptr = &bufor;			//przypisanie wskaza� na pocz�tek
					//bufora odbioru znak�w
	SS = 1;				//zwolnienie SS (na wszelki wypadek)
	SPI_Slave();			//za��czenie trybu slave
	SPIE = SPE = 1;		//zezwolenie na przerwania SPI
	. . .
}
