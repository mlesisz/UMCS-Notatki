/***************************************************
 Biblioteka funcji obs�ugi 1-Wire
 ***************************************************/
#include <reg51.h>
#include "1wire.h"

sbit one_wire_IO = P1^1;							//tu do��czony jest czujnik DS1820

#define	XTAL	7.3728e6								//cz�stotliwo�� rezonatora kwarcowego
#define	nop()	ACC++									//op�nienie - pojedynczy cykl zegarowy


//realizacja funkcji 1-WIRE RESET
bit w1_reset(void)
{
	char time_slot;
	bit err;
//1  
	time_slot = (char)(XTAL/12e6*480/4);		//480 < t < 960
	while(time_slot--)
	{
		one_wire_IO = 0;								//utrzymanie stanu niskiego na linii 1Wire
		nop();											//przez wyliczony czas "time_slot"
	}
//2	
	one_wire_IO = 1;									//ustawienie stanu wysokiego na linii 1Wire
	time_slot = (char)(XTAL/12e6*66/2);			//60 < t < 75
	while(--time_slot);
	err = one_wire_IO;								//stan niski oznacza,�e uk�ad jest obecny
															//(to tzw.presence pulse)
//3
	time_slot = (char)(XTAL/12e6*412/4);		// 480 < t
	while (time_slot--)
	{
		nop();
		nop();
	}
	
	return err | !one_wire_IO;						// stan niski = zwarcie na linii
}


//zapis lub odczyt bitu na magistral� 1WIRE
bit w1_bit_io(bit b)
{
	char time_slot;
  
	time_slot = (char)(XTAL/12e6*15/2-2);		//15 > t
	one_wire_IO = 0;									//0
	one_wire_IO = b;									//3
	while(--time_slot);								//3 + time_slot * 2
	b = one_wire_IO; 
	time_slot = (char)(XTAL/12e6*45/2);			//60 < t
	while(time_slot);
	one_wire_IO = 1;
	return (b);
}


//zapis bajtu do uk�adu 1WIRE
char w1_write(char b)
{
	char i = 8;
	do
	{
		b = b >> 1 | (w1_bit_io( b & 1 ) ? 0x80:0);
	} while( --i );
	return b;
}


//odczyt bajtu z uk�adu 1WIRE
char w1_read(void)
{
	return w1_write( 0xFF );
}


//wys�anie komendy (komend) do urz�dzenia 1W; lista 8 bajt�w do wys�ania 
//wskazywana przez ptr wype�nienie tablicy wskazywanej przez ptr oznacza, 
//�e komendy dotycz� konkretnego urz�dzenia pod��czonego do 1W; w�wczas to 
//tablica powinna zawiera� jego identyfikator 
void w1_command(unsigned char cmd, unsigned char *ptr)
{
	unsigned char byte_count = 8;
	
	w1_reset();
	if(ptr)
	{
		w1_write(MATCH_ROM);					//komendy przesy�ane do uk�adu do��czonego
		do											//do linii 1WIRE
		{
			w1_write(*ptr);
			ptr++;
		} while(--byte_count);
	}
	else
		w1_write(SKIP_ROM);					//ptr = null,komenda dla wszystkich
													//urz�dze�
	w1_write(cmd);
}

