//kody polece� interfejsu 1 Wire
#define MATCH_ROM		0x55
#define SKIP_ROM		0xCC
#define SEARCH_ROM	0xF0
 
#define SEARCH_FIRST	0xFF			//rozpocz�cie przeszukiwania 1W
#define PRESENCE_ERR	0xFF
#define DATA_ERR		0xFF
#define LAST_DEVICE	0x00			//znaleziono ostatnie urz�dzenie
//0x01 ... 0x40: kontynuacja przeszukowania

#define CONVERT_T		0x44			//polecenia realizowane przez DS1820
#define READ			0xBE
#define WRITE			0x4E
#define EE_WRITE		0x48
#define EE_RECALL		0xB8

bit w1_reset(void);
char w1_write(char b);
char w1_read(void);
void w1_command(unsigned char cmd, unsigned char *ptr);

