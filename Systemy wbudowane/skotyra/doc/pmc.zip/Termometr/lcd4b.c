//biblioteka funkcji wy�wietlacza lcd w trybie 4-bity
//-----------------------------------------------------


#include <reg51.h>
#include "LCD4B.h"

// op�nienie oko�o 1 milisekundy dla kwarcu 7,3728MHz
void Delay (unsigned int k) 	
{
	unsigned int i,j;
	for (j = 0; j < k; j++)
		for (i = 0; i <= 296; i++);
}


// zapis bajtu do lcd
void WriteByteToLcd(char X)
{
	LcdEnable = 1;
	Delay(1);
	PORT |= 0xF0;							// ustawienie g�rnej po��wki portu na "1"
	PORT &= (X | 0x0F);					// "bezkolizyjny" zapis 1-szej po��wki bajtu (przez funkcj� logiczn�)
	LcdEnable = 0;							// zapis do wy�wietlacza (opadaj�ce zbocze sygna�u E)
	Delay(1);
	LcdEnable = 1;							// zapis 2-giej po��wki bajtu
	X <<= 4;									// przesuni�cie 4x w lewo
	PORT |= 0xF0;							// ustawienie g�rnej po��wki portu na "1"
	PORT &= (X | 0x0F);					// zapis 2-giej po��wki bajtu
	LcdEnable = 0;							// opadaj�ce zbocze E - zapis do LCD
	Delay(1);
}

// zapis bajtu do rejestru kontrolnego LCD
void WriteToLcdCtrlRegister(char X)
{
	LcdReg = 0;								// ustawienie sygna��w steruj�cych
	LcdRead = 0;
	WriteByteToLcd(X);
}


// write a unsigned character to lcd screen
void LcdWrite(char X)
{
	LcdReg = 1;
	LcdRead = 0;
	WriteByteToLcd(X);
}


//czyszczenie ekranu LCD
void LcdClrScr(void)
{
	WriteToLcdCtrlRegister(0x01);
}


//inicjalizacja wy�wietlacza LCD w trybie 4 bity
void LcdInitialize(void)
{
	char i;
	
	Delay(15);
	LcdReg = LcdEnable = LcdRead = 0;// wyzerowanie linii LcdReg,LcdRead,LcdEnable
	for (i = 0; i<3; i++)
	{
		LcdEnable = 1;						// impuls na E
		PORT &= 0x3F;						// ustawienie wart.inicjuj�cej
		LcdEnable = 0;
		Delay(5);
	}
	LcdEnable = 1;							// wpisanie warto�ci 2 do rej.kontr.
	PORT &= 0x2F;							// tylko "g�rne" 4 bity
	LcdEnable = 0;
	Delay(1);
	WriteToLcdCtrlRegister(0x28);		// interfejs 4 bity,znaki 5x7
	WriteToLcdCtrlRegister(0x08);		// wy��czenie LCD
	WriteToLcdCtrlRegister(0x01);		// kasowanie ekranu,powr�t do home
	WriteToLcdCtrlRegister(0x06);		// przesuwanie kursora z inkrement.
	WriteToLcdCtrlRegister(0x0C);		// za��czenie wy�wietlacza
}

	
// ustawia kursor na wsp�rz�dnych x,y
void GotoXY(char x, char y)
{
	switch (y)								// obliczenie o ile nale�y zwi�kszy� x w zale�no�ci od warto�ci y 
	{
		case 0:
			x += 0x80;						// x = x + 0x80
			break;
		case 1:
			x += 0xC0;						// x = x + 0xC0
			break;
		case 2:
			x += 0x94;						// x = x + 0x94
			break;
		case 3:
			x += 0xD4;						// x = x + 0xD4
			break;
	}
	WriteToLcdCtrlRegister(x);
}


//ustawienie kursora na wsp�rz�dnych 0,0
void Home()
{
	WriteToLcdCtrlRegister(0x80);
}


// wy�wietla tekst na wsp�rz�dnych x, y
void WriteTextXY(char x, char y, char *S)
{
	while (*S)								// p�tla dzia�a dot�d,a� napotkany zostanie znak ko�ca �a�cuch (/0)
	{
		GotoXY(x, y);						// wyliczenie adresu dla znaku
		LcdWrite(*S);						// wy�wietlenie pojedynczego znaku
		x++; 									// nast�pna pozycja x na ekranie
		S++;									// nast�pna pozycja wska�nika,tzn.nast�pny znak napisu
		if (x > 19)							// je�li x>19 to nast�pna linia
		{
			x = 0; 
			y++;
		}
	}
}


// wy�wietla tekst na wsp�rz�dnych x, y
void WriteText(char *S)
{
	while (*S)								// p�tla dzia�a dot�d,a� napotkany zostanie znak ko�ca �a�cuch (/0)
	{
		LcdWrite(*S);						// wy�wietlenie pojedynczego znaku
		S++;
	}
}


// definiowanie znak�w z tablicy CGRom
void DefineSpecialCharacters(char *ptr)
{
	WriteToLcdCtrlRegister(0x40);		// ustawienie trybu definicji
	while (*ptr != 0)						// p�tla wykonywana do napotkania znaku ko�ca tablicy
	{
		LcdWrite(*ptr);					// zapis znaku do lcd cgram
		ptr++;								// nast�pna pozycja tablicy (wska�nika)
	}
	WriteToLcdCtrlRegister(0x80);		// prze��czenie do trybu wy�wietlania
}

 
