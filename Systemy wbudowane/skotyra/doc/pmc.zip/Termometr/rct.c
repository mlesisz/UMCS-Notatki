/*****************************************************************
 Termometr radiowy zbudowany z wykorzystaniem uk�adu AT89C2051 
 oraz modu��w RR i RT firmy Soyter Elektronik
 
 Mikrokontroler wprowadzany jest w tryb IDLE, z kt�rego wybudzany 
 jest przez przerwanie Timera 0; w�wczas to nast�puje pomiar i 
 przes�anie wyniku przez port szeregowy
******************************************************************/

#pragma TINY								//wyb�r modelu pami�ci: to rozmiar kodu
												//wynikowego nie mo�e przekroczy� 2kB
												
#pragma DEFJ(TIM1_INIT=0xF8)			//timer 1 ustala pr�dko�� transmisji
												//tutaj 2400 bod�w (SMOD b�dzie r�wny "0")

#include <reg51.h>						//do��czenie definicji rejestr�w uK
#include <stdio.h>						//biblioteka funkcji obs�ugi UART
#include "1wire.h"						//biblioteka funkcji obs�ugi uk�ad�w z
												//interfejsem 1WIRE

//definicje sta�ych symbolicznych:
#define ENABLE		1						//dla bit�w rejestr�w kontrolnych
#define DISABLE	0
#define ON	0								//dla diody LED
#define OFF	1

//definicje linii do��czenia kluczy w��czaj�cych zasilanie
//diody LED i nadajnika
sbit TRXPOWER = P1^0;					//wyj�cie steruj�ce za��czaniem zasilania nadajnika
sbit LEDDIODE = P1^7;					//wyj�cie steruj�ce za��czaniem diody LED


//program g��wny
void main (void)
{
	TMOD &= 0xF1;							//timer 0 jako 16-bitowy timer, Timer 1 bez zmian
	TL0 = TH0 = 0;							//inicjowanie warto�ci rejestr�w Timer'a 0
	TRXPOWER = LEDDIODE = OFF;			//wy��czenie diody LED i zasilania nadajnika globalne 
	EA = ET0 = ENABLE;					//zezwolenie na przyjmowanie przerwa� oraz za��czenie
												//przerwa� od Timer'a 0
	TR0 = ENABLE;							//uruchomienie Timer'a 0
	for (;;) PCON |= 0x01;				//p�tla niesko�czona, w kt�rej CPU wprowadzone w tryb IDLE 
												//oczekuje na przerwania od Timer'a 0
}

//op�nienie oko�o 1 milisekundy dla kwarcu 7,3728MHz
void delay(unsigned int time)
{
	unsigned char j;
	
	while (time-- >= 1)					//wykonanie p�tli for zajmuje oko�o 1 msek.
		for (j=0; j<65; j++);			//p�tla jest powtarzana "time" razy
}

//odczyt danych z DS1820 po konwersji
signed int odczyt_DS1820 (void)
{
	char tl, th;
	
	PCON &= 0x7F;							//ustawienie SMOD na 0 (pojedyncza szybko�� tr.przez UART)
	w1_reset();								//odczyt czujnika DS1820
	w1_command(WRITE, 0);
	w1_write(-77);
	w1_command(CONVERT_T, 0);			//uruchomienie konwersji temperatury
	delay(700);								//czas na konwersj� w/g materia��w firmy DALLAS
	w1_write(READ);						//odczyt temperatury,CRC jest pomijane!
	tl = w1_read();
	th = w1_read();
	
	if (w1_read() == -77) 
		return (tl | th << 8);			//funkcja zwraca odczyt lub
	else 
		return (0x8000);					//komunikat o b��dzie
}

//pomiar i przes�anie danych
void pomiar (void)
{
	signed int temp;
	
	temp = odczyt_DS1820();
	TRXPOWER = LEDDIODE = ON;			//za��czenie zasilania nadajnika oraz diody LED
	if (temp != 0x8000) 
		printf("%s%i\n","#",temp);		//wys�anie wyniku pomiaru przez UART
	else
		printf("%s\n","#?");				//lub komunikatu o b��dzie
	TRXPOWER = LEDDIODE = OFF;			//wy��czenie zasilania nadajnika oraz diody LED
}

//obs�uga przerwania pochodz�cego od Timer'a 0
void IRQ_Timer0 (void) interrupt 1
{
	static irqcnt = 0;					//zmienna przeznaczona na licznik wej�� do funkcji obs�ugi
												//przerwania Timer'a 0
	
	if (++irqcnt > 100)					//zwi�kszenie stanu licznika oraz podj�cie akcji, je�li > 100
	{
		TR0 = EA = DISABLE;				//wy��czenie Timera 0 i przerwa�
		irqcnt = 0;							//wyzerowanie licznika
		pomiar();							//wywo�anie funkcji pomiaru i przes�ania danych
		TR0 = EA = ENABLE;				//za��czenie Timera 0 i przerwa�
	}
}

