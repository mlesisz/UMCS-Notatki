/*****************************************************************
 Odbiornik termometru radiowego zbudowany z wykorzystaniem uk�adu 
 AT89C2051 oraz modu��w RR i RT firmy Soyter Elektronik
 
 Transmisja docieraj�ca z nadajnika poprzedzona jest znakiem 
 synchronizacji, to jest symbolem "#". Przerwanie Timer'a 0
 wykorzystywane jest w celu okre�lenia przekroczenia limitu
 oczekiwania na transmisj�.
******************************************************************/

#pragma TINY								//wyb�r modelu pami�ci: to rozmiar kodu
												//wynikowego nie mo�e przekroczy� 2kB
												
#pragma DEFJ(TIM1_INIT=0xF8)			//timer 1 ustala pr�dko�� transmisji
												//tutaj 2400 bod�w (SMOD b�dzie r�wny "0")

#include <reg51.h>						//do��czenie definicji rejestr�w uK
#include <stdio.h>						//biblioteka funkcji obs�ugi UART
#include "lcd4b.h"						//biblioteka funkcji obs�ugi wy�wietlacza LCD

//definicje sta�ych symbolicznych:
#define ENABLE		1						//dla bit�w rejestr�w kontrolnych
#define DISABLE	0
#define ON	0								//dla diody LED
#define OFF	1


//zmienna przeznaczona na licznik wej�� do funkcji 
//obs�ugi przerwania Timer'a 0
char irqcnt = 0;

//zmienna zawieraj�ca �a�cuch do wy�wietlenia; mo�e to 
//by� warto�� temperatury lub komunikat o b��dzie
char * scr = "HELLO!  ";

//wymiana funkcji "putchar" w stdio.h
int putchar (const int c)
{
	LcdWrite(c);
	return (0);
}

//program g��wny
void main (void)
{
	unsigned char znak;
	
	LcdInitialize();						//inicjalizacja LCD w trybie 4 bity
	LcdClrScr();							//czyszczenie ekranu LCD
	printf("%s", *scr);					//wypisanie tekstu powitania
	Delay(2000);							//pauza 2 sekundy
	LcdClrScr();							//ponowne czyszczenie ekranu LCD
	TR0 = EA = ENABLE;					//za��czenie Timera 0 i jego przerwa�
	
	for (;;)									//p�tla niesko�czona,w niej oczekiwanie na odbi�r
	{
		do 									//oczekiwanie na odbi�r znaku oznaczaj�cego
			znak = _getkey(); 			//pocz�tek transmisji
		while (znak == '#');
	
		Home();
		LcdWrite('*');
		scr = "";							//oczyszczenie bufora odbioru
		while (1)
		{										//je�li kod odebranych znak�w wi�kszy od kodu 
			if (znak > 0x20) scr = scr + znak;	//spacji,to do��czanie ich do �a�cucha
			else break;						//inaczej zako�czenie pracy p�tli "while"
		}
		
		irqcnt = 0;							//zerowanie licznika "timeout"
		Home();								//ustawienie si� na wsp.0,0 na wy�wietlaczu
		printf("%c%s%s",' ',scr,"st.C");	//wy�wietlenie temperatury
	}
}

//obs�uga przerwania pochodz�cego od Timer'a 0
void IRQ_Timer0 (void) interrupt 1
{
	if (++irqcnt > 230)					//zwi�kszenie stanu licznika oraz podj�cie akcji, je�li > 230
	{											//uwaga: nadajnik wysy�a dane co irqcnt>100!
	
		irqcnt = 0;							//wyzerowanie licznika
		Home();
		printf("%s","--------");		//wy�wielenie tekstu informuj�cego o b��dzie transmisji
	}
}

