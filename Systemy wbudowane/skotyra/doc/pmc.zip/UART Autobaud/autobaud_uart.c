/***************************************************************
 program do autodetekcji nastawy dla UART mikrokontrolera
 na podstawie programu Petera Danneger (http://www.specs.de/~danni/)
 ***************************************************************/
 
//#define TEST						//<-- usu� komentarz przed dyrektyw� define dla kompilacji
										//w trybie samodzielnego programu testowego

#include <reg51.h>
#include <stdio.h>

#define WORD		unsigned int			//definicja typu dla zmiennej 2-bajtowej bez znaku
#define BYTE		unsigned char			//j.w. dla zmiennej 1-bajtowej bez znaku

#define DISABLE 0								//definicja sta�ych symb.dla nastaw
#define ENABLE 1

#define TIMEOUT	20000						//TIMEOUT 10ms dla kwarcu 24MHz
#define TOLERANCE	0.05						//dopuszczalny b��d szybko�ci transmisji +/- 5%

#define T1_FACTOR	(9*16)
#define T2_FACTOR	(9*16*2/12)


union word2byte								//deklaracja unii umo�liwiaj�cej przekszta�cenie
	{												//liczby WORD w dwa pojedyncze bajty bez �adnych
	WORD w;										//dodatkowych przekszta�ce�
	struct
	{
		BYTE hi;                    		//jako pierwszy starszy bajt
		BYTE lo;
	}b;
};

WORD div_rnd(WORD x, WORD y)				//funkcja pomocnicza
{
	return (x + y/2)/y; 
}


//funkcja rozpoznawania szybko�ci transmisji asynchronicznej
//szybko�� rozpoznawana jest przez pomiar znaku o kodzie 0x0D
//               ____    __    __ __             ____
//znak 0x0D:         |__|  |__|  |  |__|__|__|__|
//numery bit�w		     0  1  2  3  4  5  6  7  8  9
void autobaud(void)
{
//definicja wyra�enie u�ywanego w tablicy "errortable"
#define LIMIT(n,t)(WORD)((n)*(1.0+(t))*T1_FACTOR)
//tablica wykaz�w limit�w odchyle� dla taktowania UART
	static WORD code errortable[] = {
			LIMIT(1,+TOLERANCE),LIMIT(1,-TOLERANCE),
			LIMIT(2,+TOLERANCE),LIMIT(2,-TOLERANCE),
			LIMIT(3,+TOLERANCE),LIMIT(3,-TOLERANCE),
			LIMIT(4,+TOLERANCE),LIMIT(4,-TOLERANCE),
			LIMIT(5,+TOLERANCE),LIMIT(5,-TOLERANCE),
			LIMIT(6,+TOLERANCE),LIMIT(6,-TOLERANCE),
			LIMIT(7,+TOLERANCE),LIMIT(7,-TOLERANCE),
			LIMIT(8,+TOLERANCE),LIMIT(8,-TOLERANCE),
			LIMIT(9,+TOLERANCE),LIMIT(9,-TOLERANCE),
			0xFFFF,LIMIT(10,-TOLERANCE)};


	WORD code *ptr;					//pomocniczy wska�nik kwalifikowany do
											//obszaru CODE

	union word2byte time1, time9;	//definicja zmiennej,kt�ra przechowywa�
											//b�dzie wyliczone nastwy dla timer�w

	EA = DISABLE;						//wy��czenie przerwa� na czas pomiaru
	TMOD = 0x11;						//Timer'y 0 i 1 jako 16-bitowe

											//etykieta dla skoku po przekroczonym limicie
Timeout:									//czasu operacji
	TCON &= 0x3F;						//zatrzymanie Timer'a 1 i zapis do rejestr�w
	TL1 = -TIMEOUT & 0xFF;			//Timer'a 1 warto�ci dla timeout
	TH1 = -TIMEOUT >> 8;

	while(RXD == 0);					//oczekiwanie na stan wysoki linii RXD
	while(RXD == 1);					//oczekiwanie na zmian� stanu RXD na niski
	TR1 = ENABLE;						//uruchomienie Timer'a 1 tj. pomiaru czasu
											//trwania impulsu
											//impuls nr.1 (rysunek(
	while(RXD == 0);					//po zmianie stanu RXD zatrzymanie Timer'a 1
	TR1 = DISABLE;						//i zapami�tanie wyniku pomiaru
	time1.b.hi = TH1;					//zapami�tanie zajmuje 5 cykli maszynowych
	time1.b.lo = TL1;
	TR1 = ENABLE;
											//pomiar impulsu numer 2, RXD 1 -> 0
	while(RXD == 1)					//je�li przepe�nienie Timer'a 1,to TIMEOUT
	if(TF1) goto Timeout;
											//pomiar impulsu numer 3, RXD 0 -> 1
	while(RXD == 0);					//oczekiwanie na zmian�

	while(RXD == 1)					//pomiar impulsu numer 4, RXD 1 -> 0
	if(TF1) goto Timeout;			//je�li przepe�nienie to TIMEOUT

	while(RXD == 0);					//pomiar impulsu numer 5, 
	TR1 = DISABLE;						//zatrzymanie Timer'a 1
	if(TF1) goto Timeout;			//je�li przepe�nienie, to TIMEOUT

	time9.b.hi = TH1;					//zapami�tanie wyniku pomiaru po pomiarze
	time9.b.lo = TL1;					//9 bit�w

	time1.w += TIMEOUT +  0;		//do wynik�w pomiaru dodajemy TIMEOUT oraz
	time9.w += TIMEOUT +  5;		//utracone 5 cykli

	if(div_rnd(time9.w,time1.w)!= 9)
	goto Timeout;						//to nie by� znak o kodzie 0x0D

//wska�nik wskazuje tablic� b��d�w transmisji i jest zwi�kszany do momentu,
//dop�ki warto�� zmierzona jest mniejsza od wskazywanej
	for(ptr=errortable; *ptr<time9.w; ptr+=2);
//je�li wyznaczona warto�� jest poni�ej dolnego limitu dla b��du, w�wczas
//b��d pomiaru i ca�y cykl jest powtarzany
	if(*(ptr+1)>=time9.w) goto Timeout;

/**********************	Inicjalizacja UART *****************************/

	TMOD = 0x21;						//ustawienie Timer'a 1 w tryb 8-bit/autoreload
	TH1 = -div_rnd(time9.w, T1_FACTOR);	//zapis zmierzonych nastaw do Timer'a 1
	TL1 = TH1;
	PCON |= 0x80;						//ustawienie SMOD na warto�� 1
	SCON = 0x52;						//zezwolenie na prac� UART (mode 1)
	TR1 = 1;								//uruchomienie Timer'a 1 taktuj�cego prac� UART
	EA = ENABLE;						//za��czenie wy��czonych na czas pomiaru przerwa�
//tryb testowy po usuni�ciu znaku komentarza sprzed #define TEST na poczatku
//programu; mikrokontroler wy�le zmierzone nastawy przez UART
#ifdef TEST
	printf("1: %u/%d   ",time1.w,div_rnd(time9.w,time1.w ));
	printf("9: %u/%d   ",time9.w,div_rnd(time9.w,9));
	printf("Nastawa: %d\n",(WORD)(256-TH1));
	while(TI == 0);
}

void main()
{
	autobaud();
#endif
}
