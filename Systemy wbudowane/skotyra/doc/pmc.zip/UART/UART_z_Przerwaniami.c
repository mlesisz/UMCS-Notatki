/*****************************************
 Obs�uga transmisji szeregowej przez UART
 z wykorzystaniem przerwa�.
******************************************/
#include <reg51.h>
 
#define ROZM_BUFORA_TX 32
#define ROZM_BUFORA_RX 32
#define OSCYLATOR 11059200
 
unsigned char buf_wysylki[ROZM_BUFORA_TX];
unsigned char buf_odbioru[ROZM_BUFORA_RX];
unsigned char do_wysylki, wyslano;
unsigned char wysylka_wylaczona;
unsigned char do_odbioru, odebrano;


//funkcja obs�uguj�ca przerwanie UART; using 2 oznacza, �e u�ywany jest bank rejestr�w
//R0..R7 numer 2
void UART_irq (void) interrupt 4 using 2
{
	if (RI != 0)											//fragment wykonywany, gdy do_odbioru znak
	{
		RI = 0;												//zerowanie flagi "do_odbioru"
		if ((do_odbioru+1) != odebrano) buf_odbioru[do_odbioru++] = SBUF;
																//pobranie znaku do bufora odbioru, gdy jego
	}															//rozmiar jest wystarczaj�cy

	if (TI != 0)											//fragment wykonywany, gdy znak do wys�ania
	{
		TI = 0;												//zerowanie flagi "do wysy�ki"
		if (do_wysylki != wyslano) 
			SBUF = buf_wysylki[wyslano++];			//je�li indeksy ilo�ci znak�w i ilo�ci znak�w do
			else wysylka_wylaczona = 1;				//wys�ania s� r�ne, pobierz i wy�lij znak
	}
}


//obliczenie rozmiaru wolnego miejsca w buforze odbioru
unsigned char rozm_bufora_odbioru (void)
{
	return (do_odbioru - odebrano);
}

//obliczenie ilo�ci znak�w pozostaj�cych do wysy�ki
unsigned char rozm_bufora_wysylki (void)
{
	return (do_wysylki - wyslano);
}

//ustawienie pr�dko�ci transmisji, inicjacja Timer'a 1
void UART_baudrate (unsigned int baudrate)
{
	EA = 0;         			                    	//wy��czenie przerwa�
	TI = 0;     											//kasowanie flagi przerwania od UART
	do_wysylki = wyslano = 0;							//nie wys�ano i nie do_odbioru �adnych danych
	wysylka_wylaczona = 1;     						//wy��czenie funkcji nadawania
	TR1 = 0;     											//zatrzymanie timer'a 1
	ET1 = 0;     											//wy��czenie przerwa� timera 1
	PCON |= 0x80;     									//SMOD = 1, mno�nik dla kwarcu x2
	TMOD &= ~0xF0;     									//ustawienie trybu pracy timer'a 1
	TMOD |= 0x20;
	TH1 = (unsigned char)(256-(OSCYLATOR/(16L*12L*baudrate)));	//wyliczenie warto�ci dla TH1
	TR1 = 1;     											//uruchomienie timer'a 1
	EA = 1;                             			//zezwolenie na przerwania
}

//inicjalizacja trybu transmisji szeregowej
void UART_inicjalizacja (void)
{
	UART_baudrate (19200);
	EA = 0;                         					//wy��czenie przerwa�
	do_wysylki = wyslano = 0;							//zerowanie indeks�w bufor�w nadawania i odbioru
	wysylka_wylaczona = 1;
	do_odbioru = odebrano = 0;
	SM0 = 0; SM1 = 1; 									//ustawienie trybu pracy UART na "mode 1"
	SM2 = 0;
	REN = 1; 												//zezwolenie na prac� odbiornika UART
	TI = RI = 0;											//kasowanie flag przerwania UART
	ES = 1; 													//zezwolenie na przyjmowanie przerwa� od UART
	PS = 0; 													//ustawienie niskiego priorytetu dla przerwania UART
	EA = 1;                         					//za��czenie przerwa�
}

//przyk�ad w�asnej implementacji funkcji wysy�aj�cej znak przez UART
signed char _putchar(unsigned char c)
{
	if ((ROZM_BUFORA_TX-rozm_bufora_wysylki ()) <= 2) return (-1);	//bufor zbyt ma�y, b��d
	EA = 0;                         					//wy��czenie przerwa�
	buf_wysylki[do_wysylki++] = c;					//wstawienie znaku do bufora nadawania
	if (wysylka_wylaczona) 								//je�li nadawanie jest wy��czone
	{
		wysylka_wylaczona = 0;
		TI = 1; 												//za��cz je
	}
	EA = 1;                         					//za��czenie przerwa�
	return (0);												//je�li operacja przebieg�a poprawnie, zwr�� 0
}

//przyk�ad wykonania funkcji odbieraj�cej znak z UART
signed int _getchar (void)
{
	unsigned char c;

	if (rozm_bufora_odbioru() == 0) return (-1);	//brak odebranych znak�w, b��d
	EA = 0;                         					//wy��czenie przerwa�
	c = buf_odbioru[odebrano++];						//pobranie znaku z bufora
	EA = 1;                         					//za��czenie przerwa�
	return (c);
}

void main()
{
	UART_inicjalizacja();
}
