/**********************************
 pojedynczy uk�ad master I2C
 RC-51
 **********************************/

#include <reg51.h>

sbit	SDA	P1^0;			//definiowanie po��cze� I2C
sbit	SCL	P1^1;

//wys�anie sekwencji START, bez badania stanu zaj�to�ci I2C
void I2C_Start(void)	
{
SDA = SCL = 1;
Delay();
SDA = 0;
Delay();
SCL = 0;
}

/* wys�anie sekwencji STOP, funkcja zwraca stan linii SDA po zako�czeniu; 
   je�li uk�ad slave wymusza stan niski SDA - b��d transmisji */
bit I2C_Stop(void)			
{
SDA = 0;
Delay();
SCL = 1;
Delay();
SDA = 1;
Delay();
return (~SDA);
}


/* odczyt bajtu z magistrali I2C; jako parametr wywo�ania podawany
   jest bit ACK, poniewa� niekt�re bajty odczytywane s� z NACK */
unsigned char I2C_Read(bit ack)
{
unsigned char bitCount = 8, temp;

SDA = 1;
do
{
    Delay();
    SCL = 1;
    Delay();
 	    temp <<= 1;		//wprowadzenie 0
    if (SDA) temp++;
    SCL = 0;
} while(--bitCount);
SDA = ack;			//wys�anie bitu ACK
Delay();
SCL = 1;
Delay();
SCL = 0;
return (temp);
}

/* wys�anie s�owa na magistral� I2C, funkcja zwraca stan bitu ACK */
bit I2C_Send(unsigned char byte)
{
unsigned char bitCount = 9;
bit temp;

do
{
 	SCL = 0;
 	SDA = byte & 0x80;		// stan SDA jako wynik iloczynu bitowego
 	byte = (byte << 1) + 1;
 	Delay();
 	SCL = 1;
 	Delay();
} while(--bitCount);

temp = SDA;
SCL = 0;
return (temp);			// ACK = 0, NACK = 1
}
